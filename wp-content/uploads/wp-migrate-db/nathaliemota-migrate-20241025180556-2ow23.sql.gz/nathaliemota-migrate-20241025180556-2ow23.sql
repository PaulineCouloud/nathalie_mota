# WordPress MySQL database migration
#
# Generated: Friday 25. October 2024 18:05 UTC
# Hostname: localhost
# Database: `local`
# URL: //nathalie-mota.local
# Path: C:\\Users\\lacom\\Local Sites\\nathalie-mota\\app\\public
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_ff_scheduled_actions, wp_fluentform_entry_details, wp_fluentform_form_analytics, wp_fluentform_form_meta, wp_fluentform_forms, wp_fluentform_logs, wp_fluentform_submission_meta, wp_fluentform_submissions, wp_links, wp_options, wp_postmeta, wp_posts, wp_smush_dir_images, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, acf-post-type, acf-taxonomy, attachment, customize_changeset, nav_menu_item, page, photo, post, wp_navigation
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=682 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-09-23 13:49:46', '2024-09-23 13:49:46', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_ff_scheduled_actions`
#

DROP TABLE IF EXISTS `wp_ff_scheduled_actions`;


#
# Table structure of table `wp_ff_scheduled_actions`
#

CREATE TABLE `wp_ff_scheduled_actions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` bigint(20) unsigned DEFAULT NULL,
  `origin_id` bigint(20) unsigned DEFAULT NULL,
  `feed_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'submission_action',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `note` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `retry_count` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_ff_scheduled_actions`
#

#
# End of data contents of table `wp_ff_scheduled_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_entry_details`
#

DROP TABLE IF EXISTS `wp_fluentform_entry_details`;


#
# Table structure of table `wp_fluentform_entry_details`
#

CREATE TABLE `wp_fluentform_entry_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) unsigned DEFAULT NULL,
  `submission_id` bigint(20) unsigned DEFAULT NULL,
  `field_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_field_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `field_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_entry_details`
#
INSERT INTO `wp_fluentform_entry_details` ( `id`, `form_id`, `submission_id`, `field_name`, `sub_field_name`, `field_value`) VALUES
(1, 3, 1, 'names', 'last_name', 'gfreztgre'),
(2, 3, 1, 'email', '', 'raphael@atlantismultimedia.fr'),
(3, 3, 1, 'input_text', '', 'gfreg'),
(4, 3, 1, 'description', '', 'retgetg'),
(5, 3, 2, 'names', 'last_name', 'hftjhd'),
(6, 3, 2, 'email', '', 'raphael@atlantismultimedia.fr'),
(7, 3, 2, 'input_text', '', '625632'),
(8, 3, 2, 'description', '', 'dthd'),
(9, 3, 3, 'names', 'last_name', 'gdsrg'),
(10, 3, 3, 'email', '', 'gdsrgh@gvbd.fr'),
(11, 3, 3, 'input_text', '', 'grdgh'),
(12, 3, 3, 'description', '', 'gdsrhd'),
(13, 3, 4, 'names', 'last_name', 'rdeh'),
(14, 3, 4, 'email', '', 'gdgh@grd.fr'),
(15, 3, 4, 'input_text', '', 'grdg'),
(16, 3, 4, 'description', '', 'grdh'),
(17, 3, 5, 'names', 'last_name', 'htrht'),
(18, 3, 5, 'email', '', 'lacomb.pauline@hotmail.fr'),
(19, 3, 5, 'description', '', 'greger') ;

#
# End of data contents of table `wp_fluentform_entry_details`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_form_analytics`
#

DROP TABLE IF EXISTS `wp_fluentform_form_analytics`;


#
# Table structure of table `wp_fluentform_form_analytics`
#

CREATE TABLE `wp_fluentform_form_analytics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `source_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `platform` char(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `browser` char(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip` char(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_form_analytics`
#
INSERT INTO `wp_fluentform_form_analytics` ( `id`, `form_id`, `user_id`, `source_url`, `platform`, `browser`, `city`, `country`, `ip`, `count`, `created_at`) VALUES
(1, 3, 0, '', 'Windows', 'Chrome', NULL, NULL, '::1', 8, '2024-09-27 09:40:36'),
(2, 3, 0, 'http://nathalie-mota.local/', 'Android', 'Chrome', NULL, NULL, '::1', 9, '2024-10-11 15:19:17'),
(3, 3, 0, 'http://nathalie-mota.local/a-propos/', 'Android', 'Chrome', NULL, NULL, '::1', 2, '2024-10-11 15:19:19'),
(4, 3, 0, 'http://nathalie-mota.local/vie-privee/', 'Windows', 'Chrome', NULL, NULL, '::1', 2, '2024-10-11 15:57:54'),
(5, 3, 0, 'http://nathalie-mota.local/photo/team-mariee/', 'Windows', 'Chrome', NULL, NULL, '::1', 1, '2024-10-11 16:07:21') ;

#
# End of data contents of table `wp_fluentform_form_analytics`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_form_meta`
#

DROP TABLE IF EXISTS `wp_fluentform_form_meta`;


#
# Table structure of table `wp_fluentform_form_meta`
#

CREATE TABLE `wp_fluentform_form_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) unsigned DEFAULT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_form_meta`
#
INSERT INTO `wp_fluentform_form_meta` ( `id`, `form_id`, `meta_key`, `value`) VALUES
(10, 3, 'formSettings', '{"confirmation":{"redirectTo":"samePage","messageToShow":"Merci pour votre message. Nous vous contacterons dans les plus brefs d\\u00e9lais","customPage":null,"samePageFormBehavior":"hide_form","customUrl":"google.com"},"restrictions":{"limitNumberOfEntries":{"enabled":false,"numberOfEntries":null,"period":"total","limitReachedMsg":"Maximum number of entries exceeded."},"scheduleForm":{"enabled":false,"start":null,"end":null,"selectedDays":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],"pendingMsg":"La soumission du formulaire n\\u2019a pas encore commenc\\u00e9e.","expiredMsg":"La soumission du formulaire est maintenant ferm\\u00e9e."},"requireLogin":{"enabled":false,"requireLoginMsg":"You must be logged in to submit the form."},"denyEmptySubmission":{"enabled":false,"message":"D\\u00e9sol\\u00e9, vous ne pouvez pas soumettre un formulaire vide. \\u00c9coutons ce que vous voulez dire."},"restrictForm":{"enabled":false,"fields":{"ip":{"status":false,"values":"","message":"Sorry! You can\'t submit a form from your IP address.","validation_type":"fail_on_condition_met"},"country":{"status":false,"values":[],"message":"Sorry! You can\'t submit a form the country you are residing.","validation_type":"fail_on_condition_met"},"keywords":{"status":false,"values":"","message":"Sorry! Your submission contains some restricted keywords."}}}},"layout":{"labelPlacement":"top","helpMessagePlacement":"with_label","errorMessagePlacement":"inline","cssClassName":"","asteriskPlacement":"asterisk-right"},"delete_entry_on_submission":"no","conv_form_per_step_save":false,"conv_form_resume_from_last_step":false,"appendSurveyResult":{"enabled":false,"showLabel":false,"showCount":false}}'),
(11, 3, 'template_name', 'blank_form'),
(12, 3, 'notifications', '{"name":"Admin Notification Email","sendTo":{"type":"email","email":"{wp.admin_email}","field":"email","routing":[{"email":null,"field":null,"operator":"=","value":null}]},"fromName":"","fromEmail":"","replyTo":"","bcc":"","subject":"[{inputs.names}] New Form Submission","message":"<p>{all_data}<\\/p>\\n<p>This form submitted at: {embed_post.permalink}<\\/p>","conditionals":{"status":false,"type":"all","conditions":[{"field":null,"operator":"=","value":null}]},"enabled":false,"email_template":""}'),
(13, 3, '_primary_email_field', 'email'),
(14, 3, '_total_views', '5'),
(15, 3, 'advancedValidationSettings', '{"status":false,"type":"all","conditions":[{"field":"","operator":"=","value":""}],"error_message":"","validation_type":"fail_on_condition_met"}') ;

#
# End of data contents of table `wp_fluentform_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_forms`
#

DROP TABLE IF EXISTS `wp_fluentform_forms`;


#
# Table structure of table `wp_fluentform_forms`
#

CREATE TABLE `wp_fluentform_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'Draft',
  `appearance_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `form_fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `has_payment` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `conditions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_forms`
#
INSERT INTO `wp_fluentform_forms` ( `id`, `title`, `status`, `appearance_settings`, `form_fields`, `has_payment`, `type`, `conditions`, `created_by`, `created_at`, `updated_at`) VALUES
(3, 'Contact', 'published', NULL, '{"fields":[{"index":0,"element":"input_name","attributes":{"name":"names","data-type":"name-element"},"settings":{"container_class":"","admin_field_label":"nom","conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]},"label_placement":""},"fields":{"first_name":{"element":"input_text","attributes":{"type":"text","name":"first_name","value":"","id":"","class":"","placeholder":"Pr\\u00e9nom","maxlength":""},"settings":{"container_class":"","label":"Pr\\u00e9nom","help_message":"","visible":false,"label_placement":"top","label_placement_options":[{"value":"","label":"Par d\\u00e9faut"},{"value":"top","label":"Haut"},{"value":"right","label":"Droite"},{"value":"bottom","label":"Bottom"},{"value":"left","label":"Gauche"},{"value":"hide_label","label":"Hidden"}],"validation_rules":{"required":{"value":false,"message":"Ce champ est requis","global_message":"Ce champ est requis","global":true}},"conditional_logics":[]},"editor_options":{"template":"inputText"}},"middle_name":{"element":"input_text","attributes":{"type":"text","name":"middle_name","value":"","id":"","class":"","placeholder":"Deuxi\\u00e8me nom","required":false,"maxlength":""},"settings":{"container_class":"","label":"Deuxi\\u00e8me nom","help_message":"","error_message":"","label_placement":"top","label_placement_options":[{"value":"","label":"Par d\\u00e9faut"},{"value":"top","label":"Haut"},{"value":"right","label":"Droite"},{"value":"bottom","label":"Bottom"},{"value":"left","label":"Gauche"},{"value":"hide_label","label":"Hidden"}],"visible":false,"validation_rules":{"required":{"value":false,"message":"Ce champ est requis","global_message":"Ce champ est requis","global":true}},"conditional_logics":[]},"editor_options":{"template":"inputText"}},"last_name":{"element":"input_text","attributes":{"type":"text","name":"last_name","value":"","id":"","class":"","placeholder":"","required":false,"maxlength":""},"settings":{"container_class":"","label":"Nom","help_message":"","error_message":"","label_placement":"top","label_placement_options":[{"value":"","label":"Par d\\u00e9faut"},{"value":"top","label":"Haut"},{"value":"right","label":"Droite"},{"value":"bottom","label":"Bottom"},{"value":"left","label":"Gauche"},{"value":"hide_label","label":"Hidden"}],"visible":true,"validation_rules":{"required":{"value":true,"message":"Ce champ est requis","global_message":"Ce champ est requis","global":true}},"conditional_logics":[]},"editor_options":{"template":"inputText"}}},"editor_options":{"title":"Name Fields","element":"name-fields","icon_class":"ff-edit-name","template":"nameFields"},"uniqElKey":"el_1727171895599"},{"index":1,"element":"input_email","attributes":{"type":"email","name":"email","value":"","id":"","class":"","placeholder":""},"settings":{"container_class":"","label":"E-mail","label_placement":"","help_message":"","admin_field_label":"email","prefix_label":"","suffix_label":"","validation_rules":{"required":{"value":true,"message":"Ce champ est requis","global_message":"Ce champ est requis","global":true},"email":{"value":true,"message":"Ce champ doit contenir un e-mail valide","global_message":"Ce champ doit contenir un e-mail valide","global":true}},"conditional_logics":[],"is_unique":"no","unique_validation_message":"L\\u2019adresse courriel doit \\u00eatre unique."},"editor_options":{"title":"E-mail","icon_class":"ff-edit-email","template":"inputText"},"uniqElKey":"el_1727171908697"},{"index":2,"element":"input_text","attributes":{"type":"text","name":"input_text","value":"","class":"","placeholder":"","maxlength":""},"settings":{"container_class":"","label":"R\\u00e9f. photo","label_placement":"","admin_field_label":"ref_photo","help_message":"","prefix_label":"","suffix_label":"","validation_rules":{"required":{"value":false,"message":"Ce champ est requis","global_message":"Ce champ est requis","global":true}},"conditional_logics":[],"is_unique":"no","unique_validation_message":"This value need to be unique."},"editor_options":{"title":"Texte simple","icon_class":"ff-edit-text","template":"inputText"},"uniqElKey":"el_1727171934291"},{"index":3,"element":"textarea","attributes":{"name":"description","value":"","id":"","class":"","placeholder":"","rows":3,"cols":2,"maxlength":""},"settings":{"container_class":"","label":"Message","admin_field_label":"message","label_placement":"","help_message":"","validation_rules":{"required":{"value":true,"message":"Ce champ est requis","global_message":"Ce champ est requis","global":true}},"conditional_logics":[]},"editor_options":{"title":"Zone de texte","icon_class":"ff-edit-textarea","template":"inputTextarea"},"uniqElKey":"el_1727172001574"}],"submitButton":{"uniqElKey":"el_1524065200616","element":"button","attributes":{"type":"submit","class":""},"settings":{"align":"left","button_style":"default","container_class":"","help_message":"","background_color":"#1a7efb","button_size":"md","color":"#ffffff","button_ui":{"type":"default","text":"Envoyer","img_url":""},"normal_styles":{"backgroundColor":"#1a7efb","borderColor":"#1a7efb","color":"#ffffff","borderRadius":"","minWidth":""},"hover_styles":{"backgroundColor":"#ffffff","borderColor":"#1a7efb","color":"#1a7efb","borderRadius":"","minWidth":""},"current_state":"normal_styles"},"editor_options":{"title":"Submit Button"}}}', 0, 'form', NULL, 1, '2024-09-24 11:58:05', '2024-10-11 11:42:56') ;

#
# End of data contents of table `wp_fluentform_forms`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_logs`
#

DROP TABLE IF EXISTS `wp_fluentform_logs`;


#
# Table structure of table `wp_fluentform_logs`
#

CREATE TABLE `wp_fluentform_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_source_id` int(10) unsigned DEFAULT NULL,
  `source_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `source_id` int(10) unsigned DEFAULT NULL,
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` char(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_logs`
#

#
# End of data contents of table `wp_fluentform_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_submission_meta`
#

DROP TABLE IF EXISTS `wp_fluentform_submission_meta`;


#
# Table structure of table `wp_fluentform_submission_meta`
#

CREATE TABLE `wp_fluentform_submission_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `response_id` bigint(20) unsigned DEFAULT NULL,
  `form_id` int(10) unsigned DEFAULT NULL,
  `meta_key` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_submission_meta`
#
INSERT INTO `wp_fluentform_submission_meta` ( `id`, `response_id`, `form_id`, `meta_key`, `value`, `status`, `user_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 3, '_entry_uid_hash', 'c0b62845a524a4041aaf7452222cb1f3', NULL, NULL, NULL, '2024-10-11 12:35:12', '2024-10-11 12:35:12'),
(2, 1, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2024-10-11 12:35:12', '2024-10-11 12:35:12'),
(3, 2, 3, '_entry_uid_hash', '81aa70bf850eb1ee440c9b709b5fa36a', NULL, NULL, NULL, '2024-10-11 12:36:06', '2024-10-11 12:36:06'),
(4, 2, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2024-10-11 12:36:06', '2024-10-11 12:36:06'),
(5, 3, 3, '_entry_uid_hash', '572e1fce34f06b1d3aaaeee8c27023d3', NULL, NULL, NULL, '2024-10-11 12:40:30', '2024-10-11 12:40:30'),
(6, 3, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2024-10-11 12:40:30', '2024-10-11 12:40:30'),
(7, 4, 3, '_entry_uid_hash', 'ea025d65801084026216123369b08ff0', NULL, NULL, NULL, '2024-10-11 12:42:21', '2024-10-11 12:42:21'),
(8, 4, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2024-10-11 12:42:21', '2024-10-11 12:42:21'),
(9, 5, 3, '_entry_uid_hash', '114a60c16321174ba6b3d7b8783dd343', NULL, NULL, NULL, '2024-10-25 13:00:15', '2024-10-25 13:00:15'),
(10, 5, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2024-10-25 13:00:15', '2024-10-25 13:00:15') ;

#
# End of data contents of table `wp_fluentform_submission_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_fluentform_submissions`
#

DROP TABLE IF EXISTS `wp_fluentform_submissions`;


#
# Table structure of table `wp_fluentform_submissions`
#

CREATE TABLE `wp_fluentform_submissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) unsigned DEFAULT NULL,
  `serial_number` int(10) unsigned DEFAULT NULL,
  `response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `source_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'unread' COMMENT 'possible values: read, unread, trashed',
  `is_favourite` tinyint(1) NOT NULL DEFAULT '0',
  `browser` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `device` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_method` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_type` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `currency` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_total` float DEFAULT NULL,
  `total_paid` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_fluentform_submissions`
#
INSERT INTO `wp_fluentform_submissions` ( `id`, `form_id`, `serial_number`, `response`, `source_url`, `user_id`, `status`, `is_favourite`, `browser`, `device`, `ip`, `city`, `country`, `payment_status`, `payment_method`, `payment_type`, `currency`, `payment_total`, `total_paid`, `created_at`, `updated_at`) VALUES
(1, 3, 1, '{"__fluent_form_embded_post_id":"1","_fluentform_3_fluentformnonce":"76687a2803","_wp_http_referer":"\\/hello-world\\/","names":{"last_name":"gfreztgre"},"email":"raphael@atlantismultimedia.fr","input_text":"gfreg","description":"retgetg"}', 'http://nathalie-mota.local/hello-world/', 1, 'unread', 0, 'Chrome', 'Windows', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-11 11:35:12', '2024-10-11 11:35:12'),
(2, 3, 2, '{"__fluent_form_embded_post_id":"1","_fluentform_3_fluentformnonce":"76687a2803","_wp_http_referer":"\\/hello-world\\/","names":{"last_name":"hftjhd"},"email":"raphael@atlantismultimedia.fr","input_text":"625632","description":"dthd"}', 'http://nathalie-mota.local/hello-world/', 1, 'unread', 0, 'Chrome', 'Windows', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-11 11:36:06', '2024-10-11 11:36:06'),
(3, 3, 3, '{"__fluent_form_embded_post_id":"6","_fluentform_3_fluentformnonce":"76687a2803","_wp_http_referer":"\\/","names":{"last_name":"gdsrg"},"email":"gdsrgh@gvbd.fr","input_text":"grdgh","description":"gdsrhd"}', 'http://nathalie-mota.local/', 1, 'unread', 0, 'Chrome', 'Windows', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-11 11:40:30', '2024-10-11 11:40:30'),
(4, 3, 4, '{"__fluent_form_embded_post_id":"6","_fluentform_3_fluentformnonce":"76687a2803","_wp_http_referer":"\\/","names":{"last_name":"rdeh"},"email":"gdgh@grd.fr","input_text":"grdg","description":"grdh"}', 'http://nathalie-mota.local/', 1, 'unread', 0, 'Chrome', 'Windows', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-11 11:42:21', '2024-10-11 11:42:21'),
(5, 3, 5, '{"__fluent_form_embded_post_id":"6","_fluentform_3_fluentformnonce":"fbced07f8c","_wp_http_referer":"\\/","names":{"last_name":"htrht"},"email":"lacomb.pauline@hotmail.fr","input_text":"","description":"greger"}', 'http://nathalie-mota.local/', 1, 'unread', 0, 'Chrome', 'Windows', '::1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-10-25 12:00:15', '2024-10-25 12:00:15') ;

#
# End of data contents of table `wp_fluentform_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1552 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'cron', 'a:16:{i:1729879572;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1729879674;a:1:{s:29:"fluentform_do_scheduled_tasks";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:21:"ff_every_five_minutes";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1729882187;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1729900800;a:1:{s:22:"wdev_logger_clear_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1729908009;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729910985;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729912785;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729914585;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1729936674;a:1:{s:42:"fluentform_do_email_report_scheduled_tasks";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1729950586;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1729951209;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1729951212;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1730124015;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1730209786;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1730447224;a:1:{s:27:"acf_update_site_health_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'auto'),
(2, 'siteurl', 'http://nathalie-mota.local', 'on'),
(3, 'home', 'http://nathalie-mota.local', 'on'),
(4, 'blogname', 'Nathalie Mota', 'on'),
(5, 'blogdescription', '', 'on'),
(6, 'users_can_register', '0', 'on'),
(7, 'admin_email', 'couloud.pauline@hotmail.com', 'on'),
(8, 'start_of_week', '1', 'on'),
(9, 'use_balanceTags', '0', 'on'),
(10, 'use_smilies', '1', 'on'),
(11, 'require_name_email', '1', 'on'),
(12, 'comments_notify', '1', 'on'),
(13, 'posts_per_rss', '10', 'on'),
(14, 'rss_use_excerpt', '0', 'on'),
(15, 'mailserver_url', 'mail.example.com', 'on'),
(16, 'mailserver_login', 'login@example.com', 'on'),
(17, 'mailserver_pass', 'password', 'on'),
(18, 'mailserver_port', '110', 'on'),
(19, 'default_category', '1', 'on'),
(20, 'default_comment_status', 'open', 'on'),
(21, 'default_ping_status', 'open', 'on'),
(22, 'default_pingback_flag', '1', 'on'),
(23, 'posts_per_page', '10', 'on'),
(24, 'date_format', 'd/m/Y', 'on'),
(25, 'time_format', 'H:i', 'on'),
(26, 'links_updated_date_format', 'F j, Y g:i a', 'on'),
(27, 'comment_moderation', '0', 'on'),
(28, 'moderation_notify', '1', 'on'),
(29, 'permalink_structure', '/%postname%/', 'on'),
(30, 'rewrite_rules', 'a:121:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:50:"categorie/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?categorie=$matches[1]&feed=$matches[2]";s:45:"categorie/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?categorie=$matches[1]&feed=$matches[2]";s:26:"categorie/([^/]+)/embed/?$";s:42:"index.php?categorie=$matches[1]&embed=true";s:38:"categorie/([^/]+)/page/?([0-9]{1,})/?$";s:49:"index.php?categorie=$matches[1]&paged=$matches[2]";s:20:"categorie/([^/]+)/?$";s:31:"index.php?categorie=$matches[1]";s:47:"format/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?format=$matches[1]&feed=$matches[2]";s:42:"format/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?format=$matches[1]&feed=$matches[2]";s:23:"format/([^/]+)/embed/?$";s:39:"index.php?format=$matches[1]&embed=true";s:35:"format/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?format=$matches[1]&paged=$matches[2]";s:17:"format/([^/]+)/?$";s:28:"index.php?format=$matches[1]";s:33:"photo/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"photo/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"photo/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"photo/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"photo/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"photo/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"photo/([^/]+)/embed/?$";s:38:"index.php?photo=$matches[1]&embed=true";s:26:"photo/([^/]+)/trackback/?$";s:32:"index.php?photo=$matches[1]&tb=1";s:34:"photo/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?photo=$matches[1]&paged=$matches[2]";s:41:"photo/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?photo=$matches[1]&cpage=$matches[2]";s:30:"photo/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?photo=$matches[1]&page=$matches[2]";s:22:"photo/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"photo/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"photo/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"photo/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"photo/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"photo/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'on'),
(31, 'hack_file', '0', 'on'),
(32, 'blog_charset', 'UTF-8', 'on'),
(33, 'moderation_keys', '', 'off'),
(34, 'active_plugins', 'a:4:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:25:"fluentform/fluentform.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";i:3;s:23:"wp-smushit/wp-smush.php";}', 'on'),
(35, 'category_base', '', 'on'),
(36, 'ping_sites', 'http://rpc.pingomatic.com/', 'on'),
(37, 'comment_max_links', '2', 'on'),
(38, 'gmt_offset', '2', 'on'),
(39, 'default_email_category', '1', 'on'),
(40, 'recently_edited', '', 'off'),
(41, 'template', 'nathaliemota_theme', 'on'),
(42, 'stylesheet', 'nathaliemota_theme', 'on'),
(43, 'comment_registration', '0', 'on'),
(44, 'html_type', 'text/html', 'on'),
(45, 'use_trackback', '0', 'on'),
(46, 'default_role', 'subscriber', 'on'),
(47, 'db_version', '57155', 'on'),
(48, 'uploads_use_yearmonth_folders', '1', 'on'),
(49, 'upload_path', '', 'on'),
(50, 'blog_public', '1', 'on'),
(51, 'default_link_category', '2', 'on'),
(52, 'show_on_front', 'page', 'on'),
(53, 'tag_base', '', 'on'),
(54, 'show_avatars', '1', 'on'),
(55, 'avatar_rating', 'G', 'on'),
(56, 'upload_url_path', '', 'on'),
(57, 'thumbnail_size_w', '150', 'on'),
(58, 'thumbnail_size_h', '150', 'on'),
(59, 'thumbnail_crop', '1', 'on'),
(60, 'medium_size_w', '300', 'on'),
(61, 'medium_size_h', '300', 'on'),
(62, 'avatar_default', 'mystery', 'on'),
(63, 'large_size_w', '1024', 'on'),
(64, 'large_size_h', '1024', 'on'),
(65, 'image_default_link_type', 'none', 'on'),
(66, 'image_default_size', '', 'on'),
(67, 'image_default_align', '', 'on'),
(68, 'close_comments_for_old_posts', '0', 'on'),
(69, 'close_comments_days_old', '14', 'on'),
(70, 'thread_comments', '1', 'on'),
(71, 'thread_comments_depth', '5', 'on'),
(72, 'page_comments', '0', 'on'),
(73, 'comments_per_page', '50', 'on'),
(74, 'default_comments_page', 'newest', 'on'),
(75, 'comment_order', 'asc', 'on'),
(76, 'sticky_posts', 'a:0:{}', 'on'),
(77, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(80, 'uninstall_plugins', 'a:0:{}', 'off'),
(81, 'timezone_string', '', 'on'),
(82, 'page_for_posts', '9', 'on'),
(83, 'page_on_front', '6', 'on'),
(84, 'default_post_format', '0', 'on'),
(85, 'link_manager_enabled', '0', 'on'),
(86, 'finished_splitting_shared_terms', '1', 'on'),
(87, 'site_icon', '0', 'on'),
(88, 'medium_large_size_w', '768', 'on'),
(89, 'medium_large_size_h', '0', 'on'),
(90, 'wp_page_for_privacy_policy', '3', 'on'),
(91, 'show_comments_cookies_opt_in', '1', 'on'),
(92, 'admin_email_lifespan', '1742651385', 'on'),
(93, 'disallowed_keys', '', 'off'),
(94, 'comment_previously_approved', '1', 'on'),
(95, 'auto_plugin_theme_update_emails', 'a:0:{}', 'off'),
(96, 'auto_update_core_dev', 'enabled', 'on'),
(97, 'auto_update_core_minor', 'enabled', 'on'),
(98, 'auto_update_core_major', 'enabled', 'on'),
(99, 'wp_force_deactivated_plugins', 'a:0:{}', 'on'),
(100, 'wp_attachment_pages_enabled', '0', 'on') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'initial_db_version', '57155', 'on'),
(102, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:69:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:27:"fluentform_dashboard_access";b:1;s:24:"fluentform_forms_manager";b:1;s:25:"fluentform_entries_viewer";b:1;s:25:"fluentform_manage_entries";b:1;s:24:"fluentform_view_payments";b:1;s:26:"fluentform_manage_payments";b:1;s:27:"fluentform_settings_manager";b:1;s:22:"fluentform_full_access";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'auto'),
(103, 'fresh_site', '0', 'auto'),
(104, 'user_count', '1', 'off'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'auto'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'auto'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(125, 'recovery_keys', 'a:0:{}', 'auto'),
(127, 'theme_mods_twentytwentyfour', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1727101300;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'off'),
(149, 'can_compress_scripts', '0', 'on'),
(154, 'finished_updating_comment_type', '1', 'auto'),
(155, 'WPLANG', 'fr_FR', 'auto'),
(156, 'new_admin_email', 'couloud.pauline@hotmail.com', 'auto'),
(171, 'current_theme', 'Nathalie Mota', 'auto'),
(172, 'theme_mods_nathaliemota_theme', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'on'),
(173, 'theme_switched', '', 'auto'),
(216, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'auto'),
(257, 'action_scheduler_hybrid_store_demarkation', '29', 'auto'),
(258, 'schema-ActionScheduler_StoreSchema', '6.0.1727171874', 'auto'),
(259, 'schema-ActionScheduler_LoggerSchema', '3.0.1727171874', 'auto'),
(260, 'fluentform_entry_details_migrated', 'yes', 'off'),
(261, 'fluentform_db_fluentform_logs_added', '1', 'off'),
(262, 'fluentform_scheduled_actions_migrated', 'yes', 'off'),
(263, '__fluentform_global_form_settings', 'a:1:{s:6:"layout";a:5:{s:14:"labelPlacement";s:3:"top";s:17:"asteriskPlacement";s:14:"asterisk-right";s:20:"helpMessagePlacement";s:10:"with_label";s:21:"errorMessagePlacement";s:6:"inline";s:12:"cssClassName";s:0:"";}}', 'off'),
(264, '_fluentform_installed_version', '5.2.2', 'off'),
(265, 'fluentform_global_modules_status', 'a:9:{s:9:"mailchimp";s:2:"no";s:14:"activecampaign";s:2:"no";s:16:"campaign_monitor";s:2:"no";s:17:"constatantcontact";s:2:"no";s:11:"getresponse";s:2:"no";s:8:"icontact";s:2:"no";s:7:"webhook";s:2:"no";s:6:"zapier";s:2:"no";s:5:"slack";s:2:"no";}', 'off'),
(266, 'recently_activated', 'a:0:{}', 'auto'),
(267, 'action_scheduler_lock_async-request-runner', '1729879582', 'auto'),
(268, 'widget_fluentform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(275, 'action_scheduler_migration_status', 'complete', 'auto'),
(460, 'acf_first_activated_version', '6.3.6', 'on'),
(461, 'acf_site_health', '{"version":"6.3.6.3","plugin_type":"Free","wp_version":"6.6.2","mysql_version":"8.0.16","is_multisite":false,"active_theme":{"name":"Nathalie Mota","version":"1.0","theme_uri":"","stylesheet":false},"active_plugins":{"fluentform\\/fluentform.php":{"name":"Fluent Forms","version":"5.2.4","plugin_uri":"https:\\/\\/wpmanageninja.com\\/wp-fluent-form\\/"},"advanced-custom-fields\\/acf.php":{"name":"Secure Custom Fields","version":"6.3.6.3","plugin_uri":"http:\\/\\/wordpress.org\\/plugins\\/advanced-custom-fields\\/"},"wp-smushit\\/wp-smush.php":{"name":"Smush","version":"3.16.6","plugin_uri":"http:\\/\\/wordpress.org\\/plugins\\/wp-smushit\\/"}},"ui_field_groups":"1","php_field_groups":"0","json_field_groups":"0","rest_field_groups":"0","number_of_fields_by_type":{"text":1,"number":1,"radio":1},"number_of_third_party_fields_by_type":[],"post_types_enabled":true,"ui_post_types":"4","json_post_types":"0","ui_taxonomies":"5","json_taxonomies":"0","rest_api_format":"light","admin_ui_enabled":true,"field_type-modal_enabled":true,"field_settings_tabs_enabled":false,"shortcode_enabled":false,"registered_acf_forms":"0","json_save_paths":1,"json_load_paths":1,"event_first_activated":1727423224,"event_first_created_post_type":1727423787,"event_first_created_taxonomy":1727423797,"event_first_created_field_group":1727424146,"last_updated":1729850266}', 'off'),
(463, 'acf_version', '6.3.6.3', 'auto'),
(495, 'categorie_children', 'a:0:{}', 'auto'),
(498, 'format_children', 'a:0:{}', 'auto'),
(815, 'category_children', 'a:0:{}', 'auto'),
(955, 'wp-smush-settings', 'a:27:{s:4:"auto";b:1;s:5:"lossy";i:0;s:10:"strip_exif";b:1;s:6:"resize";b:0;s:9:"detection";b:0;s:8:"original";b:0;s:6:"backup";b:0;s:8:"no_scale";b:0;s:10:"png_to_jpg";b:0;s:7:"nextgen";b:0;s:2:"s3";b:0;s:9:"gutenberg";b:0;s:10:"js_builder";b:0;s:5:"gform";b:0;s:3:"cdn";b:0;s:11:"auto_resize";b:0;s:4:"webp";b:1;s:5:"usage";b:0;s:17:"accessible_colors";b:0;s:9:"keep_data";b:1;s:9:"lazy_load";b:0;s:17:"background_images";b:1;s:16:"rest_api_support";b:0;s:8:"webp_mod";b:0;s:16:"background_email";b:0;s:22:"webp_direct_conversion";b:0;s:13:"webp_fallback";b:0;}', 'auto'),
(956, 'wp-smush-install-type', 'existing', 'off'),
(957, 'wp-smush-version', '3.16.6', 'off'),
(961, 'wpmudev_recommended_plugins_registered', 'a:1:{s:23:"wp-smushit/wp-smush.php";a:1:{s:13:"registered_at";i:1728997045;}}', 'off'),
(962, 'wp_smush_pre_3_12_6_site', '0', 'off'),
(964, 'wp_smush_image_sizes_state', 'a:2:{s:5:"sizes";a:6:{s:9:"thumbnail";a:3:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";b:1;}s:6:"medium";a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;}s:5:"large";a:3:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;}s:9:"1536x1536";a:3:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";b:0;}s:9:"2048x2048";a:3:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";b:0;}s:12:"medium_large";a:2:{s:5:"width";i:768;s:6:"height";i:0;}}s:4:"hash";i:46247379563;}', 'auto'),
(968, 'wpmudev_notices', 'a:3:{s:7:"plugins";a:1:{s:5:"smush";i:1728997048;}s:5:"queue";a:1:{s:5:"smush";a:3:{s:5:"email";i:1728997048;s:4:"rate";i:1728997048;s:8:"giveaway";i:1728997048;}}s:4:"done";a:0:{}}', 'off'),
(969, 'wp-smush-preset_configs', 'a:1:{i:0;a:5:{s:2:"id";i:1;s:4:"name";s:14:"Default config";s:11:"description";s:46:"Recommended performance config for every site.";s:7:"default";b:1;s:6:"config";a:2:{s:7:"configs";a:1:{s:8:"settings";a:23:{s:4:"auto";b:1;s:5:"lossy";i:1;s:10:"strip_exif";b:1;s:6:"resize";b:0;s:9:"detection";b:0;s:8:"original";b:1;s:6:"backup";b:1;s:10:"png_to_jpg";b:1;s:16:"background_email";b:0;s:7:"nextgen";b:0;s:2:"s3";b:0;s:9:"gutenberg";b:0;s:10:"js_builder";b:0;s:3:"cdn";b:0;s:11:"auto_resize";b:0;s:4:"webp";b:1;s:5:"usage";b:0;s:17:"accessible_colors";b:0;s:9:"keep_data";b:1;s:9:"lazy_load";b:0;s:17:"background_images";b:1;s:16:"rest_api_support";b:0;s:8:"webp_mod";b:0;}}s:7:"strings";a:6:{s:10:"bulk_smush";a:1:{i:0;s:221:"Smush Mode - Super\r\nAutomatic compression - Active\r\nMetadata - Active\r\nImage Resizing - Inactive\r\nOriginal Images - Active\r\nBackup Original Images - Active\r\nPNG to JPEG Conversion - Inactive\r\nEmail Notification - Inactive";}s:9:"lazy_load";a:1:{i:0;s:8:"Inactive";}s:3:"cdn";a:1:{i:0;s:8:"Inactive";}s:8:"webp_mod";a:1:{i:0;s:8:"Inactive";}s:12:"integrations";a:1:{i:0;s:112:"Gutenberg Support - Inactive\r\nWPBakery Page Builder - Inactive\r\nAmazon S3 - Inactive\r\nNextGen Gallery - Inactive";}s:8:"settings";a:1:{i:0;s:125:"Image Resize Detection - Inactive\r\nColor Accessibility - Inactive\r\nUsage Tracking - Inactive\r\nKeep Data On Uninstall - Active";}}}}}', 'off'),
(970, 'skip-smush-setup', '1', 'auto'),
(973, 'dir_smush_stats', 'a:1:{s:9:"dir_smush";a:2:{s:5:"total";i:0;s:9:"optimised";i:0;}}', 'off'),
(976, 'wp_smush_background_pre_flight', 'a:2:{s:8:"loopback";i:1728997062;s:4:"cron";i:1728997062;}', 'off'),
(977, 'wp_smush_run_optimize_on_scan_completed', '1', 'off'),
(978, 'wp-smush-optimization-global-stats', 'a:8:{s:4:"time";d:13.560000000000002;s:5:"bytes";i:857937;s:7:"percent";d:3.6000000000000001;s:11:"size_before";i:23829059;s:10:"size_after";i:22971122;s:5:"count";i:16;s:14:"attachment_ids";s:47:"40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55";s:11:"lossy_count";i:0;}', 'off'),
(979, 'wp-smush-png2jpg-global-stats', 'a:7:{s:4:"time";d:0;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:0;s:10:"size_after";i:0;s:5:"count";i:0;s:14:"attachment_ids";s:0:"";}', 'off'),
(980, 'wp-smush-resize-global-stats', 'a:7:{s:4:"time";d:0;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:0;s:10:"size_after";i:0;s:5:"count";i:0;s:14:"attachment_ids";s:0:"";}', 'off'),
(981, 'wp_smush_global_stats', 'a:4:{s:30:"stats_update_started_timestamp";i:1728997067;s:22:"image_attachment_count";i:16;s:22:"optimized_images_count";i:112;s:23:"stats_updated_timestamp";i:1728997068;}', 'off'),
(982, 'wp_smush_background_scan_process_status', 'a:7:{s:13:"in_processing";b:0;s:12:"is_cancelled";b:0;s:12:"is_completed";b:1;s:11:"total_items";i:1;s:15:"processed_items";i:1;s:12:"failed_items";i:0;s:7:"is_dead";b:0;}', 'off'),
(988, 'wp-smush-optimize-list', '', 'off'),
(991, 'wp-smush-reoptimize-list', '', 'off'),
(992, 'wp-smush-error-items-list', '', 'off'),
(993, 'wp-smush-ignored-items-list', '', 'off'),
(994, 'wp-smush-animated-items-list', '', 'off'),
(1551, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1729879556;}', 'off') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(4, 6, '_edit_lock', '1727101885:1'),
(7, 9, '_edit_lock', '1727101917:1'),
(13, 13, '_edit_lock', '1728640002:1'),
(15, 19, '_menu_item_type', 'post_type'),
(16, 19, '_menu_item_menu_item_parent', '0'),
(17, 19, '_menu_item_object_id', '6'),
(18, 19, '_menu_item_object', 'page'),
(19, 19, '_menu_item_target', ''),
(20, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(21, 19, '_menu_item_xfn', ''),
(22, 19, '_menu_item_url', ''),
(23, 20, '_menu_item_type', 'post_type'),
(24, 20, '_menu_item_menu_item_parent', '0'),
(25, 20, '_menu_item_object_id', '13'),
(26, 20, '_menu_item_object', 'page'),
(27, 20, '_menu_item_target', ''),
(28, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(29, 20, '_menu_item_xfn', ''),
(30, 20, '_menu_item_url', ''),
(41, 22, '_edit_lock', '1729241671:1'),
(42, 24, '_edit_lock', '1728890754:1'),
(43, 27, '_menu_item_type', 'post_type'),
(44, 27, '_menu_item_menu_item_parent', '0'),
(45, 27, '_menu_item_object_id', '22'),
(46, 27, '_menu_item_object', 'page'),
(47, 27, '_menu_item_target', ''),
(48, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 27, '_menu_item_xfn', ''),
(50, 27, '_menu_item_url', ''),
(51, 28, '_menu_item_type', 'post_type'),
(52, 28, '_menu_item_menu_item_parent', '0'),
(53, 28, '_menu_item_object_id', '24'),
(54, 28, '_menu_item_object', 'page'),
(55, 28, '_menu_item_target', ''),
(56, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 28, '_menu_item_xfn', ''),
(58, 28, '_menu_item_url', ''),
(64, 29, '_edit_last', '1'),
(65, 29, '_edit_lock', '1728997785:1'),
(66, 30, '_edit_last', '1'),
(67, 30, '_edit_lock', '1729604760:1'),
(68, 31, '_edit_last', '1'),
(69, 31, '_edit_lock', '1727424531:1'),
(70, 32, '_edit_last', '1'),
(71, 32, '_edit_lock', '1729857300:1'),
(72, 38, '_edit_last', '1'),
(73, 38, '_edit_lock', '1727425057:1'),
(74, 38, 'reference', 'bf2385'),
(75, 38, '_reference', 'field_66f66597aa1d2'),
(76, 38, 'annee', '2019'),
(77, 38, '_annee', 'field_66f66699f25f3'),
(78, 38, 'type', 'Argentique'),
(79, 38, '_type', 'field_66f66717ee9fb'),
(81, 40, '_wp_attached_file', '2024/09/nathalie-0-scaled.jpeg'),
(82, 40, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:30:"2024/09/nathalie-0-scaled.jpeg";s:8:"filesize";i:358300;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-0-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14887;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-0-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:86136;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-0-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7471;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-0-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:57060;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-0-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:156226;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-0-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:244086;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-0.jpeg";}'),
(83, 41, '_wp_attached_file', '2024/09/nathalie-1-scaled.jpeg'),
(84, 41, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:30:"2024/09/nathalie-1-scaled.jpeg";s:8:"filesize";i:597357;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19127;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:135592;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8513;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:85929;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:258314;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:409230;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-1.jpeg";}'),
(85, 42, '_wp_attached_file', '2024/09/nathalie-2-scaled.jpeg'),
(86, 42, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1544;s:4:"file";s:30:"2024/09/nathalie-2-scaled.jpeg";s:8:"filesize";i:962040;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-2-300x181.jpeg";s:5:"width";i:300;s:6:"height";i:181;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20800;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-2-1024x617.jpeg";s:5:"width";i:1024;s:6:"height";i:617;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:195356;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-2-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10415;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-2-768x463.jpeg";s:5:"width";i:768;s:6:"height";i:463;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:116944;}s:9:"1536x1536";a:5:{s:4:"file";s:24:"nathalie-2-1536x926.jpeg";s:5:"width";i:1536;s:6:"height";i:926;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:397242;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-2-2048x1235.jpeg";s:5:"width";i:2048;s:6:"height";i:1235;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:656045;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-2.jpeg";}'),
(87, 43, '_wp_attached_file', '2024/09/nathalie-3-scaled.jpeg'),
(88, 43, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:30:"2024/09/nathalie-3-scaled.jpeg";s:8:"filesize";i:237753;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-3-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10117;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-3-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:58656;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-3-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5043;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-3-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:68681;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-3-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:104998;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-3-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:163213;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-3.jpeg";}'),
(89, 44, '_wp_attached_file', '2024/09/nathalie-4-scaled.jpeg'),
(90, 44, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1706;s:6:"height";i:2560;s:4:"file";s:30:"2024/09/nathalie-4-scaled.jpeg";s:8:"filesize";i:668092;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-4-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18692;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-4-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:152055;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-4-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8137;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-4-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:183084;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-4-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:291050;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-4-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:464140;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-4.jpeg";}'),
(91, 45, '_wp_attached_file', '2024/09/nathalie-5-scaled.jpeg'),
(92, 45, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:30:"2024/09/nathalie-5-scaled.jpeg";s:8:"filesize";i:795730;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-5-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19806;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-5-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:155123;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-5-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8609;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-5-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:188942;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-5-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:309370;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-5-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:520741;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-5.jpeg";}'),
(93, 46, '_wp_attached_file', '2024/09/nathalie-6-scaled.jpeg'),
(94, 46, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:2048;s:4:"file";s:30:"2024/09/nathalie-6-scaled.jpeg";s:8:"filesize";i:713303;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-6-300x240.jpeg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15182;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-6-1024x819.jpeg";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:116969;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-6-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6387;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-6-768x614.jpeg";s:5:"width";i:768;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:69956;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-6-1536x1229.jpeg";s:5:"width";i:1536;s:6:"height";i:1229;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:250914;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-6-2048x1638.jpeg";s:5:"width";i:2048;s:6:"height";i:1638;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:450294;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-6.jpeg";}'),
(95, 47, '_wp_attached_file', '2024/09/nathalie-7-scaled.jpeg'),
(96, 47, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1706;s:4:"file";s:30:"2024/09/nathalie-7-scaled.jpeg";s:8:"filesize";i:382412;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-7-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14082;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-7-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:92020;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-7-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6585;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-7-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:59369;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-7-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:170145;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-7-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:267624;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-7.jpeg";}'),
(97, 48, '_wp_attached_file', '2024/09/nathalie-8-scaled.jpeg'),
(98, 48, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1709;s:6:"height";i:2560;s:4:"file";s:30:"2024/09/nathalie-8-scaled.jpeg";s:8:"filesize";i:433893;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-8-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17475;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-8-684x1024.jpeg";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:108656;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-8-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8923;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-8-768x1150.jpeg";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:128874;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-8-1025x1536.jpeg";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:198503;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-8-1367x2048.jpeg";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:305925;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-8.jpeg";}'),
(99, 49, '_wp_attached_file', '2024/09/nathalie-9-scaled.jpeg'),
(100, 49, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:30:"2024/09/nathalie-9-scaled.jpeg";s:8:"filesize";i:621814;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-9-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14785;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-9-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:114661;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-9-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7430;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-9-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:69647;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-9-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:234321;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-9-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:403356;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-9.jpeg";}'),
(101, 50, '_wp_attached_file', '2024/09/nathalie-10-scaled.jpeg'),
(102, 50, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1920;s:4:"file";s:31:"2024/09/nathalie-10-scaled.jpeg";s:8:"filesize";i:1361452;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-10-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:26249;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-10-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:268479;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-10-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9542;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-10-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:156459;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-10-1536x1152.jpeg";s:5:"width";i:1536;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:564284;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-10-2048x1536.jpeg";s:5:"width";i:2048;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:935859;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-10.jpeg";}'),
(103, 51, '_wp_attached_file', '2024/09/nathalie-11-scaled.jpeg'),
(104, 51, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1709;s:4:"file";s:31:"2024/09/nathalie-11-scaled.jpeg";s:8:"filesize";i:353187;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-11-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15413;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-11-1024x684.jpeg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:89429;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-11-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7708;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-11-768x513.jpeg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:59663;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-11-1536x1025.jpeg";s:5:"width";i:1536;s:6:"height";i:1025;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:159946;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-11-2048x1367.jpeg";s:5:"width";i:2048;s:6:"height";i:1367;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:246299;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-11.jpeg";}'),
(105, 52, '_wp_attached_file', '2024/09/nathalie-12-scaled.jpeg'),
(106, 52, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:31:"2024/09/nathalie-12-scaled.jpeg";s:8:"filesize";i:499851;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-12-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19136;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-12-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:127114;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-12-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9437;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-12-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:81929;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-12-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:230427;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-12-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:355609;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-12.jpeg";}'),
(107, 53, '_wp_attached_file', '2024/09/nathalie-13-scaled.jpeg'),
(108, 53, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:31:"2024/09/nathalie-13-scaled.jpeg";s:8:"filesize";i:271340;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-13-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10584;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-13-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67271;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-13-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5904;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-13-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:79605;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-13-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:123124;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-13-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:189807;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-13.jpeg";}'),
(109, 54, '_wp_attached_file', '2024/09/nathalie-14-scaled.jpeg'),
(110, 54, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:31:"2024/09/nathalie-14-scaled.jpeg";s:8:"filesize";i:470897;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-14-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11483;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-14-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:96567;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-14-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5717;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-14-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:117440;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-14-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:194071;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-14-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:319293;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-14.jpeg";}'),
(111, 55, '_wp_attached_file', '2024/09/nathalie-15-scaled.jpeg'),
(112, 55, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1709;s:6:"height";i:2560;s:4:"file";s:31:"2024/09/nathalie-15-scaled.jpeg";s:8:"filesize";i:657724;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-15-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19677;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-15-684x1024.jpeg";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:152305;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-15-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8560;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-15-768x1150.jpeg";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:183100;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-15-1025x1536.jpeg";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:293220;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-15-1367x2048.jpeg";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:461291;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-15.jpeg";}'),
(113, 38, '_thumbnail_id', '40'),
(114, 56, '_edit_last', '1'),
(115, 56, '_edit_lock', '1727425091:1'),
(116, 56, '_thumbnail_id', '41'),
(117, 56, 'reference', 'bf2386'),
(118, 56, '_reference', 'field_66f66597aa1d2'),
(119, 56, 'annee', '2020'),
(120, 56, '_annee', 'field_66f66699f25f3'),
(121, 56, 'type', 'Argentique'),
(122, 56, '_type', 'field_66f66717ee9fb'),
(123, 57, '_edit_last', '1'),
(124, 57, '_edit_lock', '1727425123:1'),
(125, 57, '_thumbnail_id', '42'),
(126, 57, 'reference', 'bf2387') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(127, 57, '_reference', 'field_66f66597aa1d2'),
(128, 57, 'annee', '2021'),
(129, 57, '_annee', 'field_66f66699f25f3'),
(130, 57, 'type', 'Numérique'),
(131, 57, '_type', 'field_66f66717ee9fb'),
(132, 58, '_edit_last', '1'),
(133, 58, '_edit_lock', '1727425224:1'),
(134, 58, '_thumbnail_id', '43'),
(135, 58, 'reference', 'bf2388'),
(136, 58, '_reference', 'field_66f66597aa1d2'),
(137, 58, 'annee', '2019'),
(138, 58, '_annee', 'field_66f66699f25f3'),
(139, 58, 'type', 'Argentique'),
(140, 58, '_type', 'field_66f66717ee9fb'),
(141, 59, '_edit_last', '1'),
(142, 59, '_edit_lock', '1727425243:1'),
(143, 59, '_thumbnail_id', '44'),
(144, 59, 'reference', 'bf2389'),
(145, 59, '_reference', 'field_66f66597aa1d2'),
(146, 59, 'annee', '2020'),
(147, 59, '_annee', 'field_66f66699f25f3'),
(148, 59, 'type', 'Numérique'),
(149, 59, '_type', 'field_66f66717ee9fb'),
(150, 60, '_edit_last', '1'),
(151, 60, '_edit_lock', '1727425263:1'),
(152, 60, '_thumbnail_id', '45'),
(153, 60, 'reference', 'bf2390'),
(154, 60, '_reference', 'field_66f66597aa1d2'),
(155, 60, 'annee', '2021'),
(156, 60, '_annee', 'field_66f66699f25f3'),
(157, 60, 'type', 'Numérique'),
(158, 60, '_type', 'field_66f66717ee9fb'),
(159, 61, '_edit_last', '1'),
(160, 61, '_edit_lock', '1727425283:1'),
(161, 61, '_thumbnail_id', '46'),
(162, 61, 'reference', 'bf2391'),
(163, 61, '_reference', 'field_66f66597aa1d2'),
(164, 61, 'annee', '2020'),
(165, 61, '_annee', 'field_66f66699f25f3'),
(166, 61, 'type', 'Numérique'),
(167, 61, '_type', 'field_66f66717ee9fb'),
(168, 62, '_edit_last', '1'),
(169, 62, '_edit_lock', '1727425306:1'),
(170, 62, '_thumbnail_id', '47'),
(171, 62, 'reference', 'bf2392'),
(172, 62, '_reference', 'field_66f66597aa1d2'),
(173, 62, 'annee', '2019'),
(174, 62, '_annee', 'field_66f66699f25f3'),
(175, 62, 'type', 'Numérique'),
(176, 62, '_type', 'field_66f66717ee9fb'),
(177, 63, '_edit_last', '1'),
(178, 63, '_edit_lock', '1727425325:1'),
(179, 63, '_thumbnail_id', '48'),
(180, 63, 'reference', 'bf2393'),
(181, 63, '_reference', 'field_66f66597aa1d2'),
(182, 63, 'annee', '2021'),
(183, 63, '_annee', 'field_66f66699f25f3'),
(184, 63, 'type', 'Numérique'),
(185, 63, '_type', 'field_66f66717ee9fb'),
(186, 64, '_edit_last', '1'),
(187, 64, '_edit_lock', '1727425343:1'),
(188, 64, '_thumbnail_id', '49'),
(189, 64, 'reference', 'bf2394'),
(190, 64, '_reference', 'field_66f66597aa1d2'),
(191, 64, 'annee', '2022'),
(192, 64, '_annee', 'field_66f66699f25f3'),
(193, 64, 'type', 'Numérique'),
(194, 64, '_type', 'field_66f66717ee9fb'),
(195, 65, '_edit_last', '1'),
(196, 65, '_edit_lock', '1727425363:1'),
(197, 65, '_thumbnail_id', '50'),
(198, 65, 'reference', 'bf2395'),
(199, 65, '_reference', 'field_66f66597aa1d2'),
(200, 65, 'annee', '2022'),
(201, 65, '_annee', 'field_66f66699f25f3'),
(202, 65, 'type', 'Numérique'),
(203, 65, '_type', 'field_66f66717ee9fb'),
(204, 66, '_edit_last', '1'),
(205, 66, '_edit_lock', '1727425380:1'),
(206, 66, '_thumbnail_id', '51'),
(207, 66, 'reference', 'bf2396'),
(208, 66, '_reference', 'field_66f66597aa1d2'),
(209, 66, 'annee', '2022'),
(210, 66, '_annee', 'field_66f66699f25f3'),
(211, 66, 'type', 'Argentique'),
(212, 66, '_type', 'field_66f66717ee9fb'),
(213, 67, '_edit_last', '1'),
(214, 67, '_edit_lock', '1727425399:1'),
(215, 67, '_thumbnail_id', '52'),
(216, 67, 'reference', 'bf2397'),
(217, 67, '_reference', 'field_66f66597aa1d2'),
(218, 67, 'annee', '2022'),
(219, 67, '_annee', 'field_66f66699f25f3'),
(220, 67, 'type', 'Numérique'),
(221, 67, '_type', 'field_66f66717ee9fb'),
(222, 68, '_edit_last', '1'),
(223, 68, '_edit_lock', '1727425416:1'),
(224, 68, '_thumbnail_id', '53'),
(225, 68, 'reference', 'bf2398'),
(226, 68, '_reference', 'field_66f66597aa1d2') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(227, 68, 'annee', '2022'),
(228, 68, '_annee', 'field_66f66699f25f3'),
(229, 68, 'type', 'Numérique'),
(230, 68, '_type', 'field_66f66717ee9fb'),
(231, 69, '_edit_last', '1'),
(232, 69, '_edit_lock', '1727425437:1'),
(233, 69, '_thumbnail_id', '54'),
(234, 69, 'reference', 'bf2399'),
(235, 69, '_reference', 'field_66f66597aa1d2'),
(236, 69, 'annee', '2022'),
(237, 69, '_annee', 'field_66f66699f25f3'),
(238, 69, 'type', 'Argentique'),
(239, 69, '_type', 'field_66f66717ee9fb'),
(240, 70, '_edit_last', '1'),
(241, 70, '_edit_lock', '1728998833:1'),
(242, 70, '_thumbnail_id', '55'),
(243, 70, 'reference', 'bf2400'),
(244, 70, '_reference', 'field_66f66597aa1d2'),
(245, 70, 'annee', '2022'),
(246, 70, '_annee', 'field_66f66699f25f3'),
(247, 70, 'type', 'Numérique'),
(248, 70, '_type', 'field_66f66717ee9fb'),
(249, 1, '_edit_lock', '1728639717:1'),
(252, 1, '_has_fluentform', 'a:0:{}'),
(259, 40, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.57000000000000006;s:5:"bytes";i:11344;s:7:"percent";d:1.23;s:11:"size_before";i:924166;s:10:"size_after";i:912822;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:854;s:7:"percent";d:5.7400000000000002;s:11:"size_before";i:14887;s:10:"size_after";i:14033;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:1443;s:7:"percent";d:1.6799999999999999;s:11:"size_before";i:86136;s:10:"size_after";i:84693;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.050000000000000003;s:5:"bytes";i:1516;s:7:"percent";d:2.6600000000000001;s:11:"size_before";i:57060;s:10:"size_after";i:55544;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.050000000000000003;s:5:"bytes";i:1630;s:7:"percent";d:1.04;s:11:"size_before";i:156226;s:10:"size_after";i:154596;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:2036;s:7:"percent";d:0.82999999999999996;s:11:"size_before";i:244086;s:10:"size_after";i:242050;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.28999999999999998;s:5:"bytes";i:3270;s:7:"percent";d:0.91000000000000003;s:11:"size_before";i:358300;s:10:"size_after";i:355030;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.050000000000000003;s:5:"bytes";i:595;s:7:"percent";d:7.96;s:11:"size_before";i:7471;s:10:"size_after";i:6876;}}}'),
(260, 41, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.44;s:5:"bytes";i:34570;s:7:"percent";d:2.2799999999999998;s:11:"size_before";i:1514062;s:10:"size_after";i:1479492;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1104;s:7:"percent";d:5.7699999999999996;s:11:"size_before";i:19127;s:10:"size_after";i:18023;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:2610;s:7:"percent";d:3.04;s:11:"size_before";i:85929;s:10:"size_after";i:83319;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:3601;s:7:"percent";d:2.6600000000000001;s:11:"size_before";i:135592;s:10:"size_after";i:131991;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:5735;s:7:"percent";d:2.2200000000000002;s:11:"size_before";i:258314;s:10:"size_after";i:252579;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:685;s:7:"percent";d:8.0500000000000007;s:11:"size_before";i:8513;s:10:"size_after";i:7828;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.12;s:5:"bytes";i:8122;s:7:"percent";d:1.98;s:11:"size_before";i:409230;s:10:"size_after";i:401108;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.12;s:5:"bytes";i:12713;s:7:"percent";d:2.1299999999999999;s:11:"size_before";i:597357;s:10:"size_after";i:584644;}}}'),
(261, 42, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.79000000000000004;s:5:"bytes";i:136509;s:7:"percent";d:5.79;s:11:"size_before";i:2358842;s:10:"size_after";i:2222333;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:936;s:7:"percent";d:8.9900000000000002;s:11:"size_before";i:10415;s:10:"size_after";i:9479;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1541;s:7:"percent";d:7.4100000000000001;s:11:"size_before";i:20800;s:10:"size_after";i:19259;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:7485;s:7:"percent";d:6.4000000000000004;s:11:"size_before";i:116944;s:10:"size_after";i:109459;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:11756;s:7:"percent";d:6.0199999999999996;s:11:"size_before";i:195356;s:10:"size_after";i:183600;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.14000000000000001;s:5:"bytes";i:23316;s:7:"percent";d:5.8700000000000001;s:11:"size_before";i:397242;s:10:"size_after";i:373926;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:37379;s:7:"percent";d:5.7000000000000002;s:11:"size_before";i:656045;s:10:"size_after";i:618666;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.45000000000000001;s:5:"bytes";i:54096;s:7:"percent";d:5.6200000000000001;s:11:"size_before";i:962040;s:10:"size_after";i:907944;}}}'),
(262, 43, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:1.24;s:5:"bytes";i:4273;s:7:"percent";d:0.66000000000000003;s:11:"size_before";i:648461;s:10:"size_after";i:644188;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:390;s:7:"percent";d:7.7300000000000004;s:11:"size_before";i:5043;s:10:"size_after";i:4653;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:512;s:7:"percent";d:5.0599999999999996;s:11:"size_before";i:10117;s:10:"size_after";i:9605;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:858;s:7:"percent";d:1.46;s:11:"size_before";i:58656;s:10:"size_after";i:57798;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.19;s:5:"bytes";i:504;s:7:"percent";d:0.31;s:11:"size_before";i:163213;s:10:"size_after";i:162709;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.17999999999999999;s:5:"bytes";i:860;s:7:"percent";d:1.25;s:11:"size_before";i:68681;s:10:"size_after";i:67821;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.20000000000000001;s:5:"bytes";i:784;s:7:"percent";d:0.75;s:11:"size_before";i:104998;s:10:"size_after";i:104214;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.60999999999999999;s:5:"bytes";i:365;s:7:"percent";d:0.14999999999999999;s:11:"size_before";i:237753;s:10:"size_after";i:237388;}}}'),
(263, 44, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.76000000000000001;s:5:"bytes";i:62158;s:7:"percent";d:3.48;s:11:"size_before";i:1785250;s:10:"size_after";i:1723092;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:678;s:7:"percent";d:8.3300000000000001;s:11:"size_before";i:8137;s:10:"size_after";i:7459;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:1136;s:7:"percent";d:6.0800000000000001;s:11:"size_before";i:18692;s:10:"size_after";i:17556;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:6936;s:7:"percent";d:3.79;s:11:"size_before";i:183084;s:10:"size_after";i:176148;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.10000000000000001;s:5:"bytes";i:6003;s:7:"percent";d:3.9500000000000002;s:11:"size_before";i:152055;s:10:"size_after";i:146052;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:9939;s:7:"percent";d:3.4100000000000001;s:11:"size_before";i:291050;s:10:"size_after";i:281111;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.13;s:5:"bytes";i:15397;s:7:"percent";d:3.3199999999999998;s:11:"size_before";i:464140;s:10:"size_after";i:448743;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.34999999999999998;s:5:"bytes";i:22069;s:7:"percent";d:3.2999999999999998;s:11:"size_before";i:668092;s:10:"size_after";i:646023;}}}'),
(264, 45, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:1.05;s:5:"bytes";i:94931;s:7:"percent";d:4.75;s:11:"size_before";i:1998321;s:10:"size_after";i:1903390;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:742;s:7:"percent";d:8.6199999999999992;s:11:"size_before";i:8609;s:10:"size_after";i:7867;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.059999999999999998;s:5:"bytes";i:7407;s:7:"percent";d:4.7699999999999996;s:11:"size_before";i:155123;s:10:"size_after";i:147716;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.080000000000000002;s:5:"bytes";i:14513;s:7:"percent";d:4.6900000000000004;s:11:"size_before";i:309370;s:10:"size_after";i:294857;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.23999999999999999;s:5:"bytes";i:24429;s:7:"percent";d:4.6900000000000004;s:11:"size_before";i:520741;s:10:"size_after";i:496312;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.28999999999999998;s:5:"bytes";i:37408;s:7:"percent";d:4.7000000000000002;s:11:"size_before";i:795730;s:10:"size_after";i:758322;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.059999999999999998;s:5:"bytes";i:1367;s:7:"percent";d:6.9000000000000004;s:11:"size_before";i:19806;s:10:"size_after";i:18439;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.31;s:5:"bytes";i:9065;s:7:"percent";d:4.7999999999999998;s:11:"size_before";i:188942;s:10:"size_after";i:179877;}}}'),
(265, 46, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:1.1500000000000001;s:5:"bytes";i:57211;s:7:"percent";d:3.5299999999999998;s:11:"size_before";i:1623005;s:10:"size_after";i:1565794;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:520;s:7:"percent";d:8.1400000000000006;s:11:"size_before";i:6387;s:10:"size_after";i:5867;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:763;s:7:"percent";d:5.0300000000000002;s:11:"size_before";i:15182;s:10:"size_after";i:14419;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:2287;s:7:"percent";d:3.27;s:11:"size_before";i:69956;s:10:"size_after";i:67669;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:4044;s:7:"percent";d:3.46;s:11:"size_before";i:116969;s:10:"size_after";i:112925;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.17000000000000001;s:5:"bytes";i:24088;s:7:"percent";d:3.3799999999999999;s:11:"size_before";i:713303;s:10:"size_after";i:689215;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.55000000000000004;s:5:"bytes";i:16619;s:7:"percent";d:3.6899999999999999;s:11:"size_before";i:450294;s:10:"size_after";i:433675;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.31;s:5:"bytes";i:8890;s:7:"percent";d:3.54;s:11:"size_before";i:250914;s:10:"size_after";i:242024;}}}'),
(266, 47, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.87;s:5:"bytes";i:8334;s:7:"percent";d:0.83999999999999997;s:11:"size_before";i:992237;s:10:"size_after";i:983903;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:707;s:7:"percent";d:5.0199999999999996;s:11:"size_before";i:14082;s:10:"size_after";i:13375;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:451;s:7:"percent";d:6.8499999999999996;s:11:"size_before";i:6585;s:10:"size_after";i:6134;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:1220;s:7:"percent";d:2.0499999999999998;s:11:"size_before";i:59369;s:10:"size_after";i:58149;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:1287;s:7:"percent";d:1.3999999999999999;s:11:"size_before";i:92020;s:10:"size_after";i:90733;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.059999999999999998;s:5:"bytes";i:1141;s:7:"percent";d:0.67000000000000004;s:11:"size_before";i:170145;s:10:"size_after";i:169004;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.13;s:5:"bytes";i:1953;s:7:"percent";d:0.51000000000000001;s:11:"size_before";i:382412;s:10:"size_after";i:380459;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.56999999999999995;s:5:"bytes";i:1575;s:7:"percent";d:0.58999999999999997;s:11:"size_before";i:267624;s:10:"size_after";i:266049;}}}'),
(267, 48, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:1.26;s:5:"bytes";i:20915;s:7:"percent";d:1.74;s:11:"size_before";i:1202249;s:10:"size_after";i:1181334;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:749;s:7:"percent";d:8.3900000000000006;s:11:"size_before";i:8923;s:10:"size_after";i:8174;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:1042;s:7:"percent";d:5.96;s:11:"size_before";i:17475;s:10:"size_after";i:16433;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:2515;s:7:"percent";d:2.3100000000000001;s:11:"size_before";i:108656;s:10:"size_after";i:106141;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:2752;s:7:"percent";d:2.1400000000000001;s:11:"size_before";i:128874;s:10:"size_after";i:126122;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.059999999999999998;s:5:"bytes";i:3076;s:7:"percent";d:1.55;s:11:"size_before";i:198503;s:10:"size_after";i:195427;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.17000000000000001;s:5:"bytes";i:4247;s:7:"percent";d:1.3899999999999999;s:11:"size_before";i:305925;s:10:"size_after";i:301678;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.83999999999999997;s:5:"bytes";i:6534;s:7:"percent";d:1.51;s:11:"size_before";i:433893;s:10:"size_after";i:427359;}}}'),
(268, 49, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.57000000000000006;s:5:"bytes";i:52705;s:7:"percent";d:3.6000000000000001;s:11:"size_before";i:1466014;s:10:"size_after";i:1413309;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:636;s:7:"percent";d:8.5600000000000005;s:11:"size_before";i:7430;s:10:"size_after";i:6794;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:860;s:7:"percent";d:5.8200000000000003;s:11:"size_before";i:14785;s:10:"size_after";i:13925;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.050000000000000003;s:5:"bytes";i:2202;s:7:"percent";d:3.1600000000000001;s:11:"size_before";i:69647;s:10:"size_after";i:67445;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:3307;s:7:"percent";d:2.8799999999999999;s:11:"size_before";i:114661;s:10:"size_after";i:111354;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.089999999999999997;s:5:"bytes";i:7588;s:7:"percent";d:3.2400000000000002;s:11:"size_before";i:234321;s:10:"size_after";i:226733;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.20999999999999999;s:5:"bytes";i:14244;s:7:"percent";d:3.5299999999999998;s:11:"size_before";i:403356;s:10:"size_after";i:389112;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.16;s:5:"bytes";i:23868;s:7:"percent";d:3.8399999999999999;s:11:"size_before";i:621814;s:10:"size_after";i:597946;}}}'),
(269, 50, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:1.2;s:5:"bytes";i:195998;s:7:"percent";d:5.9000000000000004;s:11:"size_before";i:3322324;s:10:"size_after";i:3126326;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:827;s:7:"percent";d:8.6699999999999999;s:11:"size_before";i:9542;s:10:"size_after";i:8715;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1770;s:7:"percent";d:6.7400000000000002;s:11:"size_before";i:26249;s:10:"size_after";i:24479;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:10365;s:7:"percent";d:6.6200000000000001;s:11:"size_before";i:156459;s:10:"size_after";i:146094;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.25;s:5:"bytes";i:34636;s:7:"percent";d:6.1399999999999997;s:11:"size_before";i:564284;s:10:"size_after";i:529648;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.35999999999999999;s:5:"bytes";i:17057;s:7:"percent";d:6.3499999999999996;s:11:"size_before";i:268479;s:10:"size_after";i:251422;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.17999999999999999;s:5:"bytes";i:55502;s:7:"percent";d:5.9299999999999997;s:11:"size_before";i:935859;s:10:"size_after";i:880357;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.33000000000000002;s:5:"bytes";i:75841;s:7:"percent";d:5.5700000000000003;s:11:"size_before";i:1361452;s:10:"size_after";i:1285611;}}}'),
(270, 51, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.66999999999999993;s:5:"bytes";i:16632;s:7:"percent";d:1.79;s:11:"size_before";i:931645;s:10:"size_after";i:915013;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:593;s:7:"percent";d:7.6900000000000004;s:11:"size_before";i:7708;s:10:"size_after";i:7115;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:1677;s:7:"percent";d:2.8100000000000001;s:11:"size_before";i:59663;s:10:"size_after";i:57986;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:1720;s:7:"percent";d:1.9199999999999999;s:11:"size_before";i:89429;s:10:"size_after";i:87709;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:833;s:7:"percent";d:5.4000000000000004;s:11:"size_before";i:15413;s:10:"size_after";i:14580;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.040000000000000001;s:5:"bytes";i:2243;s:7:"percent";d:1.3999999999999999;s:11:"size_before";i:159946;s:10:"size_after";i:157703;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.35999999999999999;s:5:"bytes";i:3555;s:7:"percent";d:1.4399999999999999;s:11:"size_before";i:246299;s:10:"size_after";i:242744;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.20000000000000001;s:5:"bytes";i:6011;s:7:"percent";d:1.7;s:11:"size_before";i:353187;s:10:"size_after";i:347176;}}}'),
(271, 52, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.56999999999999995;s:5:"bytes";i:33500;s:7:"percent";d:2.5299999999999998;s:11:"size_before";i:1323503;s:10:"size_after";i:1290003;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:867;s:7:"percent";d:9.1899999999999995;s:11:"size_before";i:9437;s:10:"size_after";i:8570;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1243;s:7:"percent";d:6.5;s:11:"size_before";i:19136;s:10:"size_after";i:17893;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:3553;s:7:"percent";d:4.3399999999999999;s:11:"size_before";i:81929;s:10:"size_after";i:78376;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:4553;s:7:"percent";d:3.5800000000000001;s:11:"size_before";i:127114;s:10:"size_after";i:122561;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.059999999999999998;s:5:"bytes";i:6291;s:7:"percent";d:2.73;s:11:"size_before";i:230427;s:10:"size_after";i:224136;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.16;s:5:"bytes";i:7839;s:7:"percent";d:2.2000000000000002;s:11:"size_before";i:355609;s:10:"size_after";i:347770;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.23000000000000001;s:5:"bytes";i:9154;s:7:"percent";d:1.8300000000000001;s:11:"size_before";i:499851;s:10:"size_after";i:490697;}}}'),
(272, 53, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.73999999999999999;s:5:"bytes";i:12770;s:7:"percent";d:1.71;s:11:"size_before";i:747635;s:10:"size_after";i:734865;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:535;s:7:"percent";d:5.0499999999999998;s:11:"size_before";i:10584;s:10:"size_after";i:10049;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:489;s:7:"percent";d:8.2799999999999994;s:11:"size_before";i:5904;s:10:"size_after";i:5415;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:1740;s:7:"percent";d:2.5899999999999999;s:11:"size_before";i:67271;s:10:"size_after";i:65531;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:1775;s:7:"percent";d:2.23;s:11:"size_before";i:79605;s:10:"size_after";i:77830;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:2822;s:7:"percent";d:1.49;s:11:"size_before";i:189807;s:10:"size_after";i:186985;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.14999999999999999;s:5:"bytes";i:2603;s:7:"percent";d:2.1099999999999999;s:11:"size_before";i:123124;s:10:"size_after";i:120521;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.42999999999999999;s:5:"bytes";i:2806;s:7:"percent";d:1.03;s:11:"size_before";i:271340;s:10:"size_after";i:268534;}}}'),
(273, 54, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.46000000000000002;s:5:"bytes";i:55496;s:7:"percent";d:4.5700000000000003;s:11:"size_before";i:1215468;s:10:"size_after";i:1159972;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:471;s:7:"percent";d:8.2400000000000002;s:11:"size_before";i:5717;s:10:"size_after";i:5246;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:657;s:7:"percent";d:5.7199999999999998;s:11:"size_before";i:11483;s:10:"size_after";i:10826;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.070000000000000007;s:5:"bytes";i:5622;s:7:"percent";d:4.79;s:11:"size_before";i:117440;s:10:"size_after";i:111818;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:4622;s:7:"percent";d:4.79;s:11:"size_before";i:96567;s:10:"size_after";i:91945;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.059999999999999998;s:5:"bytes";i:9155;s:7:"percent";d:4.7199999999999998;s:11:"size_before";i:194071;s:10:"size_after";i:184916;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.14000000000000001;s:5:"bytes";i:14426;s:7:"percent";d:4.5199999999999996;s:11:"size_before";i:319293;s:10:"size_after";i:304867;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:20543;s:7:"percent";d:4.3600000000000003;s:11:"size_before";i:470897;s:10:"size_after";i:450354;}}}'),
(274, 55, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:1.22;s:5:"bytes";i:60591;s:7:"percent";d:3.4100000000000001;s:11:"size_before";i:1775877;s:10:"size_after";i:1715286;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:757;s:7:"percent";d:8.8399999999999999;s:11:"size_before";i:8560;s:10:"size_after";i:7803;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1450;s:7:"percent";d:7.3700000000000001;s:11:"size_before";i:19677;s:10:"size_after";i:18227;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.029999999999999999;s:5:"bytes";i:6650;s:7:"percent";d:4.3700000000000001;s:11:"size_before";i:152305;s:10:"size_after";i:145655;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.050000000000000003;s:5:"bytes";i:7586;s:7:"percent";d:4.1399999999999997;s:11:"size_before";i:183100;s:10:"size_after";i:175514;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.23999999999999999;s:5:"bytes";i:14655;s:7:"percent";d:3.1800000000000002;s:11:"size_before";i:461291;s:10:"size_after";i:446636;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.67000000000000004;s:5:"bytes";i:10773;s:7:"percent";d:3.6699999999999999;s:11:"size_before";i:293220;s:10:"size_after";i:282447;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.20000000000000001;s:5:"bytes";i:18720;s:7:"percent";d:2.8500000000000001;s:11:"size_before";i:657724;s:10:"size_after";i:639004;}}}'),
(283, 85, '_wp_trash_meta_status', 'publish'),
(284, 85, '_wp_trash_meta_time', '1729857460'),
(285, 87, '_wp_trash_meta_status', 'publish'),
(286, 87, '_wp_trash_meta_time', '1729857475') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-09-23 13:49:46', '2024-09-23 13:49:46', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-10-11 11:42:34', '2024-10-11 09:42:34', '', 0, 'http://nathalie-mota.local/?p=1', 0, 'post', '', 1),
(3, 1, '2024-09-23 13:49:46', '2024-09-23 13:49:46', '<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://nathalie-mota.local.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2024-09-23 13:49:46', '2024-09-23 13:49:46', '', 0, 'http://nathalie-mota.local/?page_id=3', 0, 'page', '', 0),
(4, 0, '2024-09-23 13:49:55', '2024-09-23 13:49:55', '<!-- wp:page-list /-->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-09-23 13:49:55', '2024-09-23 13:49:55', '', 0, 'http://nathalie-mota.local/navigation/', 0, 'wp_navigation', '', 0),
(6, 1, '2024-09-23 16:33:46', '2024-09-23 14:33:46', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2024-09-23 16:33:46', '2024-09-23 14:33:46', '', 0, 'http://nathalie-mota.local/?page_id=6', 0, 'page', '', 0),
(7, 1, '2024-09-23 16:33:46', '2024-09-23 14:33:46', '', 'Accueil', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2024-09-23 16:33:46', '2024-09-23 14:33:46', '', 6, 'http://nathalie-mota.local/?p=7', 0, 'revision', '', 0),
(9, 1, '2024-09-23 16:34:22', '2024-09-23 14:34:22', '', 'Articles', '', 'publish', 'closed', 'closed', '', 'articles', '', '', '2024-09-23 16:34:22', '2024-09-23 14:34:22', '', 0, 'http://nathalie-mota.local/?page_id=9', 0, 'page', '', 0),
(10, 1, '2024-09-23 16:34:22', '2024-09-23 14:34:22', '', 'Articles', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2024-09-23 16:34:22', '2024-09-23 14:34:22', '', 9, 'http://nathalie-mota.local/?p=10', 0, 'revision', '', 0),
(13, 1, '2024-09-23 20:49:10', '2024-09-23 18:49:10', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->', 'À propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2024-10-11 11:44:38', '2024-10-11 09:44:38', '', 0, 'http://nathalie-mota.local/?page_id=13', 0, 'page', '', 0),
(14, 1, '2024-09-23 20:49:10', '2024-09-23 18:49:10', '', 'A propos', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-09-23 20:49:10', '2024-09-23 18:49:10', '', 13, 'http://nathalie-mota.local/?p=14', 0, 'revision', '', 0),
(15, 1, '2024-09-23 20:49:23', '2024-09-23 18:49:23', '', 'À propos', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-09-23 20:49:23', '2024-09-23 18:49:23', '', 13, 'http://nathalie-mota.local/?p=15', 0, 'revision', '', 0),
(19, 1, '2024-09-23 20:50:11', '2024-09-23 18:50:11', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2024-09-23 20:50:11', '2024-09-23 18:50:11', '', 0, 'http://nathalie-mota.local/19/', 1, 'nav_menu_item', '', 0),
(20, 1, '2024-09-23 20:50:11', '2024-09-23 18:50:11', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2024-09-23 20:50:11', '2024-09-23 18:50:11', '', 0, 'http://nathalie-mota.local/20/', 2, 'nav_menu_item', '', 0),
(22, 1, '2024-09-23 21:03:12', '2024-09-23 19:03:12', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Lorem ipsum</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Lorem ipsum</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>\n<!-- /wp:paragraph -->', 'Mentions légales', '', 'publish', 'closed', 'closed', '', 'mentions-legales', '', '', '2024-10-18 10:30:28', '2024-10-18 08:30:28', '', 0, 'http://nathalie-mota.local/?page_id=22', 0, 'page', '', 0),
(23, 1, '2024-09-23 21:03:12', '2024-09-23 19:03:12', '', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-09-23 21:03:12', '2024-09-23 19:03:12', '', 22, 'http://nathalie-mota.local/?p=23', 0, 'revision', '', 0),
(24, 1, '2024-09-23 21:03:28', '2024-09-23 19:03:28', '<!-- wp:paragraph -->\n<p>Notre politique de confidentialité vise à protéger vos informations personnelles conformément au Règlement Général sur la Protection des Données (RGPD). Nous collectons vos données personnelles uniquement lorsque vous interagissez avec notre site, par exemple lorsque vous laissez un commentaire ou remplissez un formulaire de contact. Ces données peuvent inclure votre nom, votre adresse e-mail, ainsi que des informations techniques comme votre adresse IP ou le type de navigateur que vous utilisez. Ces informations sont collectées pour améliorer votre expérience utilisateur, analyser le trafic du site et assurer sa sécurité.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Collecte des données personnelles</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous collectons vos informations personnelles lorsque vous soumettez des formulaires, laissez des commentaires ou interagissez avec notre site. Ces données comprennent, entre autres, votre nom, adresse e-mail et des informations techniques telles que l\'adresse IP et le type de navigateur utilisé. Nous utilisons ces informations pour améliorer la qualité de notre site, répondre à vos demandes et assurer la sécurité du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Utilisation des données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Les données collectées sont utilisées pour vous fournir des services, améliorer l’expérience utilisateur, analyser l’usage du site et garantir sa sécurité. Nous ne partageons vos informations personnelles avec des tiers que dans des cas strictement nécessaires ou lorsque la loi nous y oblige.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site utilise des cookies pour améliorer votre expérience. Un cookie est un fichier qui est déposé sur votre appareil pour analyser l’usage du site. Ces informations peuvent inclure des détails sur vos préférences de navigation, vos interactions sur le site et d\'autres données techniques. Vous pouvez désactiver les cookies via les paramètres de votre navigateur, mais cela pourrait altérer certaines fonctionnalités du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Vos droits</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Conformément au RGPD, vous avez le droit de demander l’accès aux informations que nous détenons à votre sujet, d’en demander la rectification ou la suppression, et de retirer votre consentement à tout moment. Vous pouvez également limiter le traitement de vos données ou demander la portabilité de celles-ci. Pour exercer ces droits, il vous suffit de nous contacter à [votre adresse email de contact].</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Sécurité des données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous prenons des mesures de sécurité pour protéger vos informations personnelles contre tout accès non autorisé, altération, ou destruction. Malgré nos efforts, nous ne pouvons pas garantir une sécurité absolue des données transmises via Internet.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Liens externes</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site peut contenir des liens vers des sites tiers. Nous ne sommes pas responsables des pratiques de confidentialité de ces sites, et nous vous encourageons à consulter leurs politiques de confidentialité lorsque vous les visitez.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Modifications de la politique de confidentialité</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous nous réservons le droit de modifier cette politique à tout moment. Toute modification sera affichée sur cette page, et nous vous encourageons à consulter régulièrement cette section pour rester informé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Contact</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Si vous avez des questions concernant cette politique ou si vous souhaitez exercer vos droits en matière de protection des données, vous pouvez nous contacter.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'publish', 'closed', 'closed', '', 'vie-privee', '', '', '2024-10-14 09:23:35', '2024-10-14 07:23:35', '', 0, 'http://nathalie-mota.local/?page_id=24', 0, 'page', '', 0),
(25, 1, '2024-09-23 21:03:28', '2024-09-23 19:03:28', '', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2024-09-23 21:03:28', '2024-09-23 19:03:28', '', 24, 'http://nathalie-mota.local/?p=25', 0, 'revision', '', 0),
(27, 1, '2024-09-23 21:04:37', '2024-09-23 19:04:37', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2024-09-23 21:04:37', '2024-09-23 19:04:37', '', 0, 'http://nathalie-mota.local/27/', 1, 'nav_menu_item', '', 0),
(28, 1, '2024-09-23 21:04:37', '2024-09-23 19:04:37', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2024-09-23 21:04:37', '2024-09-23 19:04:37', '', 0, 'http://nathalie-mota.local/28/', 2, 'nav_menu_item', '', 0),
(29, 1, '2024-09-27 09:56:27', '2024-09-27 07:56:27', 'a:35:{s:9:"post_type";s:5:"photo";s:22:"advanced_configuration";b:1;s:13:"import_source";s:0:"";s:11:"import_date";s:0:"";s:6:"labels";a:33:{s:4:"name";s:6:"Photos";s:13:"singular_name";s:5:"Photo";s:9:"menu_name";s:6:"Photos";s:9:"all_items";s:15:"Tous les Photos";s:9:"edit_item";s:14:"Modifier Photo";s:9:"view_item";s:10:"Voir Photo";s:10:"view_items";s:11:"Voir Photos";s:12:"add_new_item";s:13:"Ajouter Photo";s:7:"add_new";s:13:"Ajouter Photo";s:8:"new_item";s:14:"Nouvelle Photo";s:17:"parent_item_colon";s:16:"Photo parente :";s:12:"search_items";s:17:"Rechercher Photos";s:9:"not_found";s:20:"Aucun photos trouvé";s:18:"not_found_in_trash";s:38:"Aucun photos trouvé dans la corbeille";s:8:"archives";s:18:"Archives des Photo";s:10:"attributes";s:19:"Attributs des Photo";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:16:"insert_into_item";s:19:"Insérer dans photo";s:21:"uploaded_to_this_item";s:25:"Téléversé sur ce photo";s:17:"filter_items_list";s:23:"Filtrer la liste photos";s:14:"filter_by_date";s:23:"Filtrer photos par date";s:21:"items_list_navigation";s:31:"Navigation dans la liste Photos";s:10:"items_list";s:12:"Liste Photos";s:14:"item_published";s:14:"Photo publié.";s:24:"item_published_privately";s:24:"Photo publié en privé.";s:22:"item_reverted_to_draft";s:28:"Photo repassé en brouillon.";s:14:"item_scheduled";s:16:"Photo planifié.";s:12:"item_updated";s:18:"Photo mis à jour.";s:9:"item_link";s:10:"Lien Photo";s:21:"item_link_description";s:22:"Un lien vers un photo.";}s:11:"description";s:0:"";s:6:"public";b:1;s:12:"hierarchical";b:0;s:19:"exclude_from_search";b:0;s:18:"publicly_queryable";b:1;s:7:"show_ui";b:1;s:12:"show_in_menu";b:1;s:17:"admin_menu_parent";s:0:"";s:17:"show_in_admin_bar";b:1;s:17:"show_in_nav_menus";b:1;s:12:"show_in_rest";b:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:5:"wp/v2";s:21:"rest_controller_class";s:24:"WP_REST_Posts_Controller";s:13:"menu_position";s:0:"";s:9:"menu_icon";a:2:{s:4:"type";s:9:"dashicons";s:5:"value";s:22:"dashicons-format-image";}s:19:"rename_capabilities";b:0;s:24:"singular_capability_name";s:4:"post";s:22:"plural_capability_name";s:5:"posts";s:8:"supports";a:2:{i:0;s:5:"title";i:1;s:9:"thumbnail";}s:10:"taxonomies";a:2:{i:0;s:9:"categorie";i:1;s:6:"format";}s:11:"has_archive";b:0;s:16:"has_archive_slug";s:0:"";s:7:"rewrite";a:4:{s:17:"permalink_rewrite";s:13:"post_type_key";s:10:"with_front";s:1:"1";s:5:"feeds";s:1:"0";s:5:"pages";s:1:"1";}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:10:"can_export";b:1;s:16:"delete_with_user";b:0;s:20:"register_meta_box_cb";s:0:"";s:16:"enter_title_here";s:0:"";}', 'Photos', 'photos', 'publish', 'closed', 'closed', '', 'post_type_66f663d97a986', '', '', '2024-09-27 10:16:47', '2024-09-27 08:16:47', '', 0, 'http://nathalie-mota.local/?post_type=acf-post-type&#038;p=29', 0, 'acf-post-type', '', 0),
(30, 1, '2024-09-27 09:56:37', '2024-09-27 07:56:37', 'a:29:{s:8:"taxonomy";s:9:"categorie";s:11:"object_type";a:1:{i:0;s:5:"photo";}s:22:"advanced_configuration";i:0;s:13:"import_source";s:0:"";s:11:"import_date";s:0:"";s:6:"labels";a:25:{s:4:"name";s:11:"Catégories";s:13:"singular_name";s:10:"Catégorie";s:9:"menu_name";s:11:"Catégories";s:9:"all_items";s:20:"Tous les Catégories";s:9:"edit_item";s:19:"Modifier Catégorie";s:9:"view_item";s:15:"Voir Catégorie";s:11:"update_item";s:25:"Mettre à jour Catégorie";s:12:"add_new_item";s:18:"Ajouter Catégorie";s:13:"new_item_name";s:25:"Nom du nouveau Catégorie";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:22:"Rechercher Catégories";s:9:"most_used";s:0:"";s:9:"not_found";s:25:"Aucun catégories trouvé";s:8:"no_terms";s:17:"Aucun catégories";s:22:"name_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:24:"parent_field_description";s:0:"";s:22:"desc_field_description";s:0:"";s:14:"filter_by_item";s:0:"";s:21:"items_list_navigation";s:36:"Navigation dans la liste Catégories";s:10:"items_list";s:17:"Liste Catégories";s:13:"back_to_items";s:30:"← Aller à « catégories »";s:9:"item_link";s:15:"Lien Catégorie";s:21:"item_link_description";s:26:"Un lien vers un catégorie";}s:11:"description";s:0:"";s:12:"capabilities";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:6:"public";i:1;s:18:"publicly_queryable";i:1;s:12:"hierarchical";i:1;s:7:"show_ui";i:1;s:12:"show_in_menu";i:1;s:17:"show_in_nav_menus";i:1;s:12:"show_in_rest";i:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:5:"wp/v2";s:21:"rest_controller_class";s:24:"WP_REST_Terms_Controller";s:13:"show_tagcloud";i:1;s:18:"show_in_quick_edit";i:1;s:17:"show_admin_column";i:0;s:7:"rewrite";a:3:{s:17:"permalink_rewrite";s:12:"taxonomy_key";s:10:"with_front";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:12:"default_term";a:1:{s:20:"default_term_enabled";s:1:"0";}s:4:"sort";i:0;s:8:"meta_box";s:7:"default";s:11:"meta_box_cb";s:0:"";s:20:"meta_box_sanitize_cb";s:0:"";}', 'Catégories', 'categories', 'publish', 'closed', 'closed', '', 'taxonomy_66f6640cbe18b', '', '', '2024-09-27 10:11:04', '2024-09-27 08:11:04', '', 0, 'http://nathalie-mota.local/?post_type=acf-taxonomy&#038;p=30', 0, 'acf-taxonomy', '', 0),
(31, 1, '2024-09-27 09:57:22', '2024-09-27 07:57:22', 'a:29:{s:8:"taxonomy";s:6:"format";s:11:"object_type";a:1:{i:0;s:5:"photo";}s:22:"advanced_configuration";i:0;s:13:"import_source";s:0:"";s:11:"import_date";s:0:"";s:6:"labels";a:25:{s:4:"name";s:7:"Formats";s:13:"singular_name";s:6:"Format";s:9:"menu_name";s:7:"Formats";s:9:"all_items";s:16:"Tous les Formats";s:9:"edit_item";s:15:"Modifier Format";s:9:"view_item";s:11:"Voir Format";s:11:"update_item";s:21:"Mettre à jour Format";s:12:"add_new_item";s:14:"Ajouter Format";s:13:"new_item_name";s:21:"Nom du nouveau Format";s:11:"parent_item";s:0:"";s:17:"parent_item_colon";s:0:"";s:12:"search_items";s:18:"Rechercher Formats";s:9:"most_used";s:0:"";s:9:"not_found";s:21:"Aucun formats trouvé";s:8:"no_terms";s:13:"Aucun formats";s:22:"name_field_description";s:0:"";s:22:"slug_field_description";s:0:"";s:24:"parent_field_description";s:0:"";s:22:"desc_field_description";s:0:"";s:14:"filter_by_item";s:0:"";s:21:"items_list_navigation";s:32:"Navigation dans la liste Formats";s:10:"items_list";s:13:"Liste Formats";s:13:"back_to_items";s:26:"← Aller à « formats »";s:9:"item_link";s:11:"Lien Format";s:21:"item_link_description";s:22:"Un lien vers un format";}s:11:"description";s:0:"";s:12:"capabilities";a:4:{s:12:"manage_terms";s:17:"manage_categories";s:10:"edit_terms";s:17:"manage_categories";s:12:"delete_terms";s:17:"manage_categories";s:12:"assign_terms";s:10:"edit_posts";}s:6:"public";i:1;s:18:"publicly_queryable";i:1;s:12:"hierarchical";i:1;s:7:"show_ui";i:1;s:12:"show_in_menu";i:1;s:17:"show_in_nav_menus";i:1;s:12:"show_in_rest";i:1;s:9:"rest_base";s:0:"";s:14:"rest_namespace";s:5:"wp/v2";s:21:"rest_controller_class";s:24:"WP_REST_Terms_Controller";s:13:"show_tagcloud";i:1;s:18:"show_in_quick_edit";i:1;s:17:"show_admin_column";i:0;s:7:"rewrite";a:3:{s:17:"permalink_rewrite";s:12:"taxonomy_key";s:10:"with_front";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";}s:9:"query_var";s:13:"post_type_key";s:14:"query_var_name";s:0:"";s:12:"default_term";a:1:{s:20:"default_term_enabled";s:1:"0";}s:4:"sort";i:0;s:8:"meta_box";s:7:"default";s:11:"meta_box_cb";s:0:"";s:20:"meta_box_sanitize_cb";s:0:"";}', 'Formats', 'formats', 'publish', 'closed', 'closed', '', 'taxonomy_66f6655294443', '', '', '2024-09-27 10:11:09', '2024-09-27 08:11:09', '', 0, 'http://nathalie-mota.local/?post_type=acf-taxonomy&#038;p=31', 0, 'acf-taxonomy', '', 0),
(32, 1, '2024-09-27 10:02:26', '2024-09-27 08:02:26', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"photo";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Photo', 'photo', 'publish', 'closed', 'closed', '', 'group_66f66597336f3', '', '', '2024-09-27 10:09:51', '2024-09-27 08:09:51', '', 0, 'http://nathalie-mota.local/?post_type=acf-field-group&#038;p=32', 0, 'acf-field-group', '', 0),
(33, 1, '2024-09-27 10:02:26', '2024-09-27 08:02:26', 'a:12:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:23:"Référence de la photo";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:17:"allow_in_bindings";i:0;s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Référence', 'reference', 'publish', 'closed', 'closed', '', 'field_66f66597aa1d2', '', '', '2024-09-27 10:02:26', '2024-09-27 08:02:26', '', 32, 'http://nathalie-mota.local/?post_type=acf-field&p=33', 0, 'acf-field', '', 0),
(34, 1, '2024-09-27 10:04:28', '2024-09-27 08:04:28', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:6:"number";s:12:"instructions";s:20:"Date de prise de vue";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:17:"allow_in_bindings";i:0;s:11:"placeholder";s:0:"";s:4:"step";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Année', 'annee', 'publish', 'closed', 'closed', '', 'field_66f66699f25f3', '', '', '2024-09-27 10:04:28', '2024-09-27 08:04:28', '', 32, 'http://nathalie-mota.local/?post_type=acf-field&p=34', 1, 'acf-field', '', 0),
(35, 1, '2024-09-27 10:07:55', '2024-09-27 08:07:55', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"radio";s:12:"instructions";s:43:"Type de la photo (Argentique ou numérique)";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:10:"Argentique";s:10:"Argentique";s:10:"Numérique";s:10:"Numérique";}s:13:"default_value";s:10:"Numérique";s:13:"return_format";s:5:"value";s:10:"allow_null";i:0;s:12:"other_choice";i:0;s:17:"allow_in_bindings";i:0;s:6:"layout";s:8:"vertical";s:17:"save_other_choice";i:0;}', 'Type', 'type', 'publish', 'closed', 'closed', '', 'field_66f66717ee9fb', '', '', '2024-09-27 10:07:55', '2024-09-27 08:07:55', '', 32, 'http://nathalie-mota.local/?post_type=acf-field&p=35', 2, 'acf-field', '', 0),
(38, 1, '2024-09-27 10:13:24', '2024-09-27 08:13:24', '', 'Santé !', '', 'publish', 'closed', 'closed', '', 'sante', '', '', '2024-09-27 10:20:01', '2024-09-27 08:20:01', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=38', 0, 'photo', '', 0),
(40, 1, '2024-09-27 10:18:18', '2024-09-27 08:18:18', '', 'nathalie-0', '', 'inherit', 'open', 'closed', '', 'nathalie-0', '', '', '2024-09-27 10:18:18', '2024-09-27 08:18:18', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-0.jpeg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2024-09-27 10:18:24', '2024-09-27 08:18:24', '', 'nathalie-1', '', 'inherit', 'open', 'closed', '', 'nathalie-1', '', '', '2024-09-27 10:18:24', '2024-09-27 08:18:24', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2024-09-27 10:18:30', '2024-09-27 08:18:30', '', 'nathalie-2', '', 'inherit', 'open', 'closed', '', 'nathalie-2', '', '', '2024-09-27 10:18:30', '2024-09-27 08:18:30', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2024-09-27 10:18:34', '2024-09-27 08:18:34', '', 'nathalie-3', '', 'inherit', 'open', 'closed', '', 'nathalie-3', '', '', '2024-09-27 10:18:34', '2024-09-27 08:18:34', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-3.jpeg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2024-09-27 10:18:40', '2024-09-27 08:18:40', '', 'nathalie-4', '', 'inherit', 'open', 'closed', '', 'nathalie-4', '', '', '2024-09-27 10:18:40', '2024-09-27 08:18:40', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-4.jpeg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2024-09-27 10:18:45', '2024-09-27 08:18:45', '', 'nathalie-5', '', 'inherit', 'open', 'closed', '', 'nathalie-5', '', '', '2024-09-27 10:18:45', '2024-09-27 08:18:45', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-5.jpeg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2024-09-27 10:18:51', '2024-09-27 08:18:51', '', 'nathalie-6', '', 'inherit', 'open', 'closed', '', 'nathalie-6', '', '', '2024-09-27 10:18:51', '2024-09-27 08:18:51', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-6.jpeg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2024-09-27 10:18:57', '2024-09-27 08:18:57', '', 'nathalie-7', '', 'inherit', 'open', 'closed', '', 'nathalie-7', '', '', '2024-09-27 10:18:57', '2024-09-27 08:18:57', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-7.jpeg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2024-09-27 10:19:01', '2024-09-27 08:19:01', '', 'nathalie-8', '', 'inherit', 'open', 'closed', '', 'nathalie-8', '', '', '2024-09-27 10:19:01', '2024-09-27 08:19:01', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-8.jpeg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2024-09-27 10:19:07', '2024-09-27 08:19:07', '', 'nathalie-9', '', 'inherit', 'open', 'closed', '', 'nathalie-9', '', '', '2024-09-27 10:19:07', '2024-09-27 08:19:07', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-9.jpeg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2024-09-27 10:19:13', '2024-09-27 08:19:13', '', 'nathalie-10', '', 'inherit', 'open', 'closed', '', 'nathalie-10', '', '', '2024-09-27 10:19:13', '2024-09-27 08:19:13', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-10.jpeg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2024-09-27 10:19:19', '2024-09-27 08:19:19', '', 'nathalie-11', '', 'inherit', 'open', 'closed', '', 'nathalie-11', '', '', '2024-09-27 10:19:19', '2024-09-27 08:19:19', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-11.jpeg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2024-09-27 10:19:24', '2024-09-27 08:19:24', '', 'nathalie-12', '', 'inherit', 'open', 'closed', '', 'nathalie-12', '', '', '2024-09-27 10:19:24', '2024-09-27 08:19:24', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-12.jpeg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2024-09-27 10:19:31', '2024-09-27 08:19:31', '', 'nathalie-13', '', 'inherit', 'open', 'closed', '', 'nathalie-13', '', '', '2024-09-27 10:19:31', '2024-09-27 08:19:31', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-13.jpeg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2024-09-27 10:19:37', '2024-09-27 08:19:37', '', 'nathalie-14', '', 'inherit', 'open', 'closed', '', 'nathalie-14', '', '', '2024-09-27 10:19:37', '2024-09-27 08:19:37', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-14.jpeg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2024-09-27 10:19:43', '2024-09-27 08:19:43', '', 'nathalie-15', '', 'inherit', 'open', 'closed', '', 'nathalie-15', '', '', '2024-09-27 10:19:43', '2024-09-27 08:19:43', '', 38, 'http://nathalie-mota.local/wp-content/uploads/2024/09/nathalie-15.jpeg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2024-09-27 10:20:33', '2024-09-27 08:20:33', '', 'Et bon anniversaire !', '', 'publish', 'closed', 'closed', '', 'et-bon-anniversaire', '', '', '2024-09-27 10:20:33', '2024-09-27 08:20:33', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=56', 0, 'photo', '', 0),
(57, 1, '2024-09-27 10:21:04', '2024-09-27 08:21:04', '', 'Let\'s party!', '', 'publish', 'closed', 'closed', '', 'lets-party', '', '', '2024-09-27 10:21:04', '2024-09-27 08:21:04', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=57', 0, 'photo', '', 0),
(58, 1, '2024-09-27 10:21:28', '2024-09-27 08:21:28', '', 'Tout est installé', '', 'publish', 'closed', 'closed', '', 'tout-est-installe', '', '', '2024-09-27 10:22:48', '2024-09-27 08:22:48', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=58', 0, 'photo', '', 0),
(59, 1, '2024-09-27 10:23:06', '2024-09-27 08:23:06', '', 'Vers l\'éternité', '', 'publish', 'closed', 'closed', '', 'vers-leternite', '', '', '2024-09-27 10:23:06', '2024-09-27 08:23:06', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=59', 0, 'photo', '', 0),
(60, 1, '2024-09-27 10:23:25', '2024-09-27 08:23:25', '', 'Embrassez la mariée', '', 'publish', 'closed', 'closed', '', 'embrassez-la-mariee', '', '', '2024-09-27 10:23:25', '2024-09-27 08:23:25', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=60', 0, 'photo', '', 0),
(61, 1, '2024-09-27 10:23:46', '2024-09-27 08:23:46', '', 'Dansons ensemble', '', 'publish', 'closed', 'closed', '', 'dansons-ensemble', '', '', '2024-09-27 10:23:46', '2024-09-27 08:23:46', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=61', 0, 'photo', '', 0),
(62, 1, '2024-09-27 10:24:07', '2024-09-27 08:24:07', '', 'Le menu', '', 'publish', 'closed', 'closed', '', 'le-menu', '', '', '2024-09-27 10:24:07', '2024-09-27 08:24:07', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=62', 0, 'photo', '', 0),
(63, 1, '2024-09-27 10:24:28', '2024-09-27 08:24:28', '', 'Au bal masqué', '', 'publish', 'closed', 'closed', '', 'au-bal-masque', '', '', '2024-09-27 10:24:28', '2024-09-27 08:24:28', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=63', 0, 'photo', '', 0),
(64, 1, '2024-09-27 10:24:46', '2024-09-27 08:24:46', '', 'Let\'s dance!', '', 'publish', 'closed', 'closed', '', 'lets-dance', '', '', '2024-09-27 10:24:46', '2024-09-27 08:24:46', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=64', 0, 'photo', '', 0),
(65, 1, '2024-09-27 10:25:05', '2024-09-27 08:25:05', '', 'Jour de match', '', 'publish', 'closed', 'closed', '', 'jour-de-match', '', '', '2024-09-27 10:25:05', '2024-09-27 08:25:05', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=65', 0, 'photo', '', 0),
(66, 1, '2024-09-27 10:25:24', '2024-09-27 08:25:24', '', 'Préparation', '', 'publish', 'closed', 'closed', '', 'preparation', '', '', '2024-09-27 10:25:24', '2024-09-27 08:25:24', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=66', 0, 'photo', '', 0),
(67, 1, '2024-09-27 10:25:42', '2024-09-27 08:25:42', '', 'Bière ou eau plate ?', '', 'publish', 'closed', 'closed', '', 'biere-ou-eau-plate', '', '', '2024-09-27 10:25:42', '2024-09-27 08:25:42', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=67', 0, 'photo', '', 0),
(68, 1, '2024-09-27 10:25:59', '2024-09-27 08:25:59', '', 'Bouquet final', '', 'publish', 'closed', 'closed', '', 'bouquet-final', '', '', '2024-09-27 10:25:59', '2024-09-27 08:25:59', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=68', 0, 'photo', '', 0),
(69, 1, '2024-09-27 10:26:20', '2024-09-27 08:26:20', '', 'Du soir au matin', '', 'publish', 'closed', 'closed', '', 'du-soir-au-matin', '', '', '2024-09-27 10:26:20', '2024-09-27 08:26:20', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=69', 0, 'photo', '', 0),
(70, 1, '2024-09-27 10:26:44', '2024-09-27 08:26:44', '', 'Team mariée', '', 'publish', 'closed', 'closed', '', 'team-mariee', '', '', '2024-09-27 10:26:44', '2024-09-27 08:26:44', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=70', 0, 'photo', '', 0),
(72, 1, '2024-10-11 11:34:57', '2024-10-11 09:34:57', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[fluentform id="3"]\n<!-- /wp:shortcode -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-10-11 11:34:57', '2024-10-11 09:34:57', '', 1, 'http://nathalie-mota.local/?p=72', 0, 'revision', '', 0),
(73, 1, '2024-10-11 11:35:22', '2024-10-11 09:35:22', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-10-11 11:35:22', '2024-10-11 09:35:22', '', 1, 'http://nathalie-mota.local/?p=73', 0, 'revision', '', 0),
(74, 1, '2024-10-11 11:35:45', '2024-10-11 09:35:45', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:shortcode -->\n[fluentform id="3"]\n<!-- /wp:shortcode -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-10-11 11:35:45', '2024-10-11 09:35:45', '', 1, 'http://nathalie-mota.local/?p=74', 0, 'revision', '', 0),
(75, 1, '2024-10-11 11:42:34', '2024-10-11 09:42:34', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2024-10-11 11:42:34', '2024-10-11 09:42:34', '', 1, 'http://nathalie-mota.local/?p=75', 0, 'revision', '', 0),
(76, 1, '2024-10-11 11:44:38', '2024-10-11 09:44:38', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->', 'À propos', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-10-11 11:44:38', '2024-10-11 09:44:38', '', 13, 'http://nathalie-mota.local/?p=76', 0, 'revision', '', 0),
(77, 1, '2024-10-14 09:01:53', '2024-10-14 07:01:53', '<!-- wp:paragraph -->\n<p>Votre vie privée est très importante pour nous. Cette politique de confidentialité décrit comment nous collectons, utilisons et protégeons vos informations personnelles lorsque vous visitez notre site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">1. Collecte des données personnelles</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous collectons vos données personnelles uniquement lorsque vous interagissez avec notre site. Cela peut inclure, mais sans s\'y limiter :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li>Votre nom, adresse e-mail et autres informations de contact lorsque vous soumettez un formulaire ou laissez un commentaire.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Des informations techniques, telles que votre adresse IP, le type de navigateur, et les pages visitées via les cookies.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Les données de navigation collectées via des outils analytiques comme Google Analytics.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">2. Utilisation des données</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Les informations personnelles que nous collectons sont utilisées pour :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li>Répondre à vos demandes et interagir avec vous.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Améliorer la qualité de notre site et analyser son usage.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Assurer la sécurité et le bon fonctionnement du site.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Nous ne partagerons jamais vos données avec des tiers sans votre consentement, sauf si cela est requis par la loi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">3. Cookies</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site utilise des cookies pour améliorer votre expérience utilisateur. Les cookies sont de petits fichiers stockés sur votre appareil qui collectent des informations sur votre visite. Vous pouvez désactiver les cookies dans les paramètres de votre navigateur, mais cela pourrait affecter certaines fonctionnalités du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">4. Vos droits</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Conformément au RGPD, vous avez le droit de :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li>Accéder aux informations personnelles que nous détenons à votre sujet.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Demander la rectification ou la suppression de vos données.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Retirer votre consentement au traitement de vos données à tout moment.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Limiter ou vous opposer au traitement de vos données personnelles.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Demander la portabilité de vos données.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Pour exercer ces droits, vous pouvez nous contacter à [votre adresse email de contact].</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">5. Sécurité des données</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous prenons toutes les précautions nécessaires pour protéger vos informations personnelles contre la perte, l\'accès non autorisé, la divulgation ou l\'altération. Cependant, nous ne pouvons pas garantir la sécurité absolue des informations transmises via Internet.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">6. Liens externes</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site peut contenir des liens vers des sites externes. Nous ne sommes pas responsables des pratiques de confidentialité de ces sites. Nous vous encourageons à lire leur politique de confidentialité lorsque vous les visitez.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">7. Modifications de la politique de confidentialité</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous nous réservons le droit de modifier cette politique à tout moment. Les changements seront publiés sur cette page, et nous vous recommandons de la consulter régulièrement.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":4} -->\n<h4 class="wp-block-heading">8. Contact</h4>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Si vous avez des questions concernant cette politique de confidentialité, vous pouvez nous contacter.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2024-10-14 09:01:53', '2024-10-14 07:01:53', '', 24, 'http://nathalie-mota.local/?p=77', 0, 'revision', '', 0),
(78, 1, '2024-10-14 09:02:43', '2024-10-14 07:02:43', '<!-- wp:paragraph -->\n<p>Votre vie privée est très importante pour nous. Cette politique de confidentialité décrit comment nous collectons, utilisons et protégeons vos informations personnelles lorsque vous visitez notre site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">1. Collecte des données personnelles</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous collectons vos données personnelles uniquement lorsque vous interagissez avec notre site. Cela peut inclure, mais sans s\'y limiter :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li>Votre nom, adresse e-mail et autres informations de contact lorsque vous soumettez un formulaire ou laissez un commentaire.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Des informations techniques, telles que votre adresse IP, le type de navigateur, et les pages visitées via les cookies.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Les données de navigation collectées via des outils analytiques comme Google Analytics.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">2. Utilisation des données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Les informations personnelles que nous collectons sont utilisées pour :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li>Répondre à vos demandes et interagir avec vous.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Améliorer la qualité de notre site et analyser son usage.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Assurer la sécurité et le bon fonctionnement du site.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Nous ne partagerons jamais vos données avec des tiers sans votre consentement, sauf si cela est requis par la loi.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">3. Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site utilise des cookies pour améliorer votre expérience utilisateur. Les cookies sont de petits fichiers stockés sur votre appareil qui collectent des informations sur votre visite. Vous pouvez désactiver les cookies dans les paramètres de votre navigateur, mais cela pourrait affecter certaines fonctionnalités du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">4. Vos droits</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Conformément au RGPD, vous avez le droit de :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class="wp-block-list"><!-- wp:list-item -->\n<li>Accéder aux informations personnelles que nous détenons à votre sujet.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Demander la rectification ou la suppression de vos données.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Retirer votre consentement au traitement de vos données à tout moment.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Limiter ou vous opposer au traitement de vos données personnelles.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Demander la portabilité de vos données.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Pour exercer ces droits, vous pouvez nous contacter à [votre adresse email de contact].</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">5. Sécurité des données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous prenons toutes les précautions nécessaires pour protéger vos informations personnelles contre la perte, l\'accès non autorisé, la divulgation ou l\'altération. Cependant, nous ne pouvons pas garantir la sécurité absolue des informations transmises via Internet.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">6. Liens externes</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site peut contenir des liens vers des sites externes. Nous ne sommes pas responsables des pratiques de confidentialité de ces sites. Nous vous encourageons à lire leur politique de confidentialité lorsque vous les visitez.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">7. Modifications de la politique de confidentialité</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous nous réservons le droit de modifier cette politique à tout moment. Les changements seront publiés sur cette page, et nous vous recommandons de la consulter régulièrement.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">8. Contact</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Si vous avez des questions concernant cette politique de confidentialité, vous pouvez nous contacter.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2024-10-14 09:02:43', '2024-10-14 07:02:43', '', 24, 'http://nathalie-mota.local/?p=78', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(79, 1, '2024-10-14 09:23:08', '2024-10-14 07:23:08', '<!-- wp:paragraph -->\n<p>Notre politique de confidentialité vise à protéger vos informations personnelles conformément au Règlement Général sur la Protection des Données (RGPD). Nous collectons vos données personnelles uniquement lorsque vous interagissez avec notre site, par exemple lorsque vous laissez un commentaire ou remplissez un formulaire de contact. Ces données peuvent inclure votre nom, votre adresse e-mail, ainsi que des informations techniques comme votre adresse IP ou le type de navigateur que vous utilisez. Ces informations sont collectées pour améliorer votre expérience utilisateur, analyser le trafic du site et assurer sa sécurité.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Collecte des données personnelles</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous collectons vos informations personnelles lorsque vous soumettez des formulaires, laissez des commentaires ou interagissez avec notre site. Ces données comprennent, entre autres, votre nom, adresse e-mail et des informations techniques telles que l\'adresse IP et le type de navigateur utilisé. Nous utilisons ces informations pour améliorer la qualité de notre site, répondre à vos demandes et assurer la sécurité du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Utilisation des données</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Les données collectées sont utilisées pour vous fournir des services, améliorer l’expérience utilisateur, analyser l’usage du site et garantir sa sécurité. Nous ne partageons vos informations personnelles avec des tiers que dans des cas strictement nécessaires ou lorsque la loi nous y oblige.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Cookies</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site utilise des cookies pour améliorer votre expérience. Un cookie est un fichier qui est déposé sur votre appareil pour analyser l’usage du site. Ces informations peuvent inclure des détails sur vos préférences de navigation, vos interactions sur le site et d\'autres données techniques. Vous pouvez désactiver les cookies via les paramètres de votre navigateur, mais cela pourrait altérer certaines fonctionnalités du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Vos droits</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Conformément au RGPD, vous avez le droit de demander l’accès aux informations que nous détenons à votre sujet, d’en demander la rectification ou la suppression, et de retirer votre consentement à tout moment. Vous pouvez également limiter le traitement de vos données ou demander la portabilité de celles-ci. Pour exercer ces droits, il vous suffit de nous contacter à [votre adresse email de contact].</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Sécurité des données</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous prenons des mesures de sécurité pour protéger vos informations personnelles contre tout accès non autorisé, altération, ou destruction. Malgré nos efforts, nous ne pouvons pas garantir une sécurité absolue des données transmises via Internet.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Liens externes</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site peut contenir des liens vers des sites tiers. Nous ne sommes pas responsables des pratiques de confidentialité de ces sites, et nous vous encourageons à consulter leurs politiques de confidentialité lorsque vous les visitez.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Modifications de la politique de confidentialité</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous nous réservons le droit de modifier cette politique à tout moment. Toute modification sera affichée sur cette page, et nous vous encourageons à consulter régulièrement cette section pour rester informé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"level":3} -->\n<h3 class="wp-block-heading">Contact</h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Si vous avez des questions concernant cette politique ou si vous souhaitez exercer vos droits en matière de protection des données, vous pouvez nous contacter.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2024-10-14 09:23:08', '2024-10-14 07:23:08', '', 24, 'http://nathalie-mota.local/?p=79', 0, 'revision', '', 0),
(80, 1, '2024-10-14 09:23:35', '2024-10-14 07:23:35', '<!-- wp:paragraph -->\n<p>Notre politique de confidentialité vise à protéger vos informations personnelles conformément au Règlement Général sur la Protection des Données (RGPD). Nous collectons vos données personnelles uniquement lorsque vous interagissez avec notre site, par exemple lorsque vous laissez un commentaire ou remplissez un formulaire de contact. Ces données peuvent inclure votre nom, votre adresse e-mail, ainsi que des informations techniques comme votre adresse IP ou le type de navigateur que vous utilisez. Ces informations sont collectées pour améliorer votre expérience utilisateur, analyser le trafic du site et assurer sa sécurité.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Collecte des données personnelles</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous collectons vos informations personnelles lorsque vous soumettez des formulaires, laissez des commentaires ou interagissez avec notre site. Ces données comprennent, entre autres, votre nom, adresse e-mail et des informations techniques telles que l\'adresse IP et le type de navigateur utilisé. Nous utilisons ces informations pour améliorer la qualité de notre site, répondre à vos demandes et assurer la sécurité du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Utilisation des données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Les données collectées sont utilisées pour vous fournir des services, améliorer l’expérience utilisateur, analyser l’usage du site et garantir sa sécurité. Nous ne partageons vos informations personnelles avec des tiers que dans des cas strictement nécessaires ou lorsque la loi nous y oblige.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site utilise des cookies pour améliorer votre expérience. Un cookie est un fichier qui est déposé sur votre appareil pour analyser l’usage du site. Ces informations peuvent inclure des détails sur vos préférences de navigation, vos interactions sur le site et d\'autres données techniques. Vous pouvez désactiver les cookies via les paramètres de votre navigateur, mais cela pourrait altérer certaines fonctionnalités du site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Vos droits</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Conformément au RGPD, vous avez le droit de demander l’accès aux informations que nous détenons à votre sujet, d’en demander la rectification ou la suppression, et de retirer votre consentement à tout moment. Vous pouvez également limiter le traitement de vos données ou demander la portabilité de celles-ci. Pour exercer ces droits, il vous suffit de nous contacter à [votre adresse email de contact].</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Sécurité des données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous prenons des mesures de sécurité pour protéger vos informations personnelles contre tout accès non autorisé, altération, ou destruction. Malgré nos efforts, nous ne pouvons pas garantir une sécurité absolue des données transmises via Internet.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Liens externes</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Notre site peut contenir des liens vers des sites tiers. Nous ne sommes pas responsables des pratiques de confidentialité de ces sites, et nous vous encourageons à consulter leurs politiques de confidentialité lorsque vous les visitez.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Modifications de la politique de confidentialité</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Nous nous réservons le droit de modifier cette politique à tout moment. Toute modification sera affichée sur cette page, et nous vous encourageons à consulter régulièrement cette section pour rester informé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Contact</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Si vous avez des questions concernant cette politique ou si vous souhaitez exercer vos droits en matière de protection des données, vous pouvez nous contacter.</p>\n<!-- /wp:paragraph -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2024-10-14 09:23:35', '2024-10-14 07:23:35', '', 24, 'http://nathalie-mota.local/?p=80', 0, 'revision', '', 0),
(82, 1, '2024-10-18 10:29:05', '2024-10-18 08:29:05', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>\n<!-- /wp:paragraph -->', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-10-18 10:29:05', '2024-10-18 08:29:05', '', 22, 'http://nathalie-mota.local/?p=82', 0, 'revision', '', 0),
(83, 1, '2024-10-18 10:30:28', '2024-10-18 08:30:28', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Lorem ipsum</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Lorem ipsum</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur? At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.</p>\n<!-- /wp:paragraph -->', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2024-10-18 10:30:28', '2024-10-18 08:30:28', '', 22, 'http://nathalie-mota.local/?p=83', 0, 'revision', '', 0),
(84, 1, '2024-10-22 10:27:46', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-10-22 10:27:46', '0000-00-00 00:00:00', '', 0, 'http://nathalie-mota.local/?p=84', 0, 'post', '', 0),
(85, 1, '2024-10-25 13:57:40', '2024-10-25 11:57:40', '{"nav_menu_item[-2568098880191379500]":{"value":{"object_id":9,"object":"page","menu_item_parent":0,"position":3,"type":"post_type","title":"Articles","url":"http:\\/\\/nathalie-mota.local\\/articles\\/","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Articles","nav_menu_term_id":2,"_invalid":false,"type_label":"Page des articles"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2024-10-25 11:57:40"}}', '', '', 'trash', 'closed', 'closed', '', '56b00363-53fc-4ae2-b87d-3283019b8265', '', '', '2024-10-25 13:57:40', '2024-10-25 11:57:40', '', 0, 'http://nathalie-mota.local/56b00363-53fc-4ae2-b87d-3283019b8265/', 0, 'customize_changeset', '', 0),
(87, 1, '2024-10-25 13:57:55', '2024-10-25 11:57:55', '{"nav_menu_item[86]":{"value":false,"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2024-10-25 11:57:55"}}', '', '', 'trash', 'closed', 'closed', '', 'ecdb9886-f4a2-4813-b29f-86f1a54bdaec', '', '', '2024-10-25 13:57:55', '2024-10-25 11:57:55', '', 0, 'http://nathalie-mota.local/ecdb9886-f4a2-4813-b29f-86f1a54bdaec/', 0, 'customize_changeset', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_smush_dir_images`
#

DROP TABLE IF EXISTS `wp_smush_dir_images`;


#
# Table structure of table `wp_smush_dir_images`
#

CREATE TABLE `wp_smush_dir_images` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path_hash` char(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lossy` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `error` varchar(55) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `file_time` int(10) unsigned DEFAULT NULL,
  `last_scan` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `meta` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path_hash` (`path_hash`),
  KEY `image_size` (`image_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_smush_dir_images`
#

#
# End of data contents of table `wp_smush_dir_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(19, 2, 0),
(20, 2, 0),
(27, 3, 0),
(28, 3, 0),
(38, 4, 0),
(38, 8, 0),
(56, 4, 0),
(56, 8, 0),
(57, 5, 0),
(57, 8, 0),
(58, 6, 0),
(58, 9, 0),
(59, 6, 0),
(59, 9, 0),
(60, 6, 0),
(60, 9, 0),
(61, 6, 0),
(61, 8, 0),
(62, 6, 0),
(62, 8, 0),
(63, 5, 0),
(63, 9, 0),
(64, 6, 0),
(64, 8, 0),
(65, 7, 0),
(65, 8, 0),
(66, 5, 0),
(66, 8, 0),
(67, 5, 0),
(67, 8, 0),
(68, 6, 0),
(68, 9, 0),
(69, 6, 0),
(69, 9, 0),
(70, 6, 0),
(70, 9, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'nav_menu', '', 0, 2),
(4, 4, 'categorie', '', 0, 2),
(5, 5, 'categorie', '', 0, 4),
(6, 6, 'categorie', '', 0, 9),
(7, 7, 'categorie', '', 0, 1),
(8, 8, 'format', '', 0, 9),
(9, 9, 'format', '', 0, 7) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Principal', 'principal', 0),
(3, 'Footer', 'footer', 0),
(4, 'Réception', 'reception', 0),
(5, 'Concert', 'concert', 0),
(6, 'Mariage', 'mariage', 0),
(7, 'Télévision', 'television', 0),
(8, 'Paysage', 'paysage', 0),
(9, 'Portrait', 'portrait', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'pauline_cld'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:"a1cd3206d0edc63482dd29020e8fd3404df02e234aa1dd6a750f7cc321dd20dc";a:4:{s:10:"expiration";i:1729848236;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";s:5:"login";i:1728638636;}s:64:"a6a107d7361a4a7c62d30f6ee942321bd18d03de33f0f0c750f976ef361beae6";a:4:{s:10:"expiration";i:1730098786;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";s:5:"login";i:1728889186;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '84'),
(18, 1, 'wp_persisted_preferences', 'a:3:{s:4:"core";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:10:"openPanels";a:3:{i:0;s:11:"post-status";i:1;s:24:"taxonomy-panel-categorie";i:2;s:21:"taxonomy-panel-format";}}s:14:"core/edit-post";a:1:{s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2024-09-27T08:14:14.896Z";}'),
(19, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(20, 1, 'acf_user_settings', 'a:2:{s:19:"post-type-first-run";b:1;s:20:"taxonomies-first-run";b:1;}'),
(21, 1, 'closedpostboxes_acf-post-type', 'a:0:{}'),
(22, 1, 'metaboxhidden_acf-post-type', 'a:1:{i:0;s:7:"slugdiv";}'),
(23, 1, 'manageedit-acf-taxonomycolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(24, 1, 'closedpostboxes_acf-taxonomy', 'a:0:{}'),
(25, 1, 'metaboxhidden_acf-taxonomy', 'a:2:{i:0;s:21:"acf-advanced-settings";i:1;s:7:"slugdiv";}'),
(26, 1, 'wp_user-settings', 'libraryContent=browse'),
(27, 1, 'wp_user-settings-time', '1727425196') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'pauline_cld', '$P$B/KyEMJJjtvD98ca.e63buMKgxMctk1', 'pauline_cld', 'couloud.pauline@hotmail.com', 'http://nathalie-mota.local', '2024-09-23 13:49:45', '', 0, 'pauline_cld') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

